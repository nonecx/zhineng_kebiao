#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
recognize_schedule.py — robust table recognition for timetable images.

Pipeline
--------
1.  Structure detection (pure CV, no OCR):
      * binarise with Otsu
      * vertical rules   -> column boundaries
      * horizontal rules -> row boundaries (dotted rules are bridged first)
      * the longest run of equal row spacing is the data region; the rules
        above it are the header
2.  Column semantics:
      * OCR every header cell (one band per header row, joined) so each column
        can be labelled 星期 / 班 / 第N节 / 上午 / 下午
      * a column labelled 星期 starts a new table
3.  Day semantics:
      * the 星期 column holds vertically-stacked text (星 / 期 / 一 ...);
        reading it row by row tells us where each day block begins
4.  Cell recognition:
      * every cell is cropped from the known grid (no text detection needed)
        and recognised in one batched pass with RapidOCR's recognition model
5.  Clean-up:
      * document-level self-correction of systematic OCR confusions
        (e.g. 申脑 -> 电脑) using character frequency and confidence
      * merged vertical cells (e.g. 班会 spanning several rows) are detected
        and joined in reading order
6.  Projection:
      * the recognised grid is (day x class x period); the app's CSV wants
        (period x day) for one class, so a class is selected and projected

Output
------
stdout: one JSON object. Diagnostics go to stderr so the JSON stays parseable.
        With --debug an overlay PNG is written next to the CSV.

Usage
-----
    python recognize_schedule.py --image a.png --out outdir --class "高二(3)班"
    python recognize_schedule.py --image a.png --out outdir --class-no 5
    python recognize_schedule.py --from-grid outdir/grid.json --class-no 5 --out outdir
"""

from __future__ import annotations

import argparse
import csv
import json
import os
import re
import shutil
import sys
import unicodedata
from collections import Counter, defaultdict
from typing import Dict, List, Optional, Sequence, Tuple

import cv2
import numpy as np

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

WEEKDAYS = ["星期一", "星期二", "星期三", "星期四", "星期五", "星期六", "星期日"]
DAY_CHARS = "一二三四五六日"

# A day glyph read below this confidence is not trusted (一/二/三 are often
# misread as 日 at very low confidence).
DAY_MIN_CONFIDENCE = 0.30

V_RULE_RUN_FRACTION = 0.30    # a vertical rule spans >=30% of the image height
RELAXED_V_RULE_FRACTION = 0.15  # second-chance pass for fuzzy/blurred photos
H_RULE_WIDTH_FRACTION = 0.55  # a horizontal rule spans >=55% of the table width
RULE_GAP_PX = 3               # rule pixels this close merge into one boundary
PITCH_TOLERANCE = 0.10        # row gaps count as equal pitch within +/-10%

# Photos smaller than this are upscaled first so rules and glyphs keep enough
# resolution to survive binarisation.
MIN_PROCESS_DIM = 700

# ─── page region + working scale ────────────────────────────────────────────
#
# A user does not send a scan of the page; they send a screenshot of whatever
# was showing it (a PDF viewer, a phone gallery, a chat window) or a photo of
# the page on a desk. Two things break, and they are independent:
#
# 1. `binarize` is a *global* Otsu threshold. A dark application chrome around
#    the page reads as ink — a 1140x672 viewer screenshot comes out 64% ink —
#    and every horizontal rule measurement dies with it.
# 2. The page is drawn at roughly half scale, so the class-row pitch falls to
#    ~10px. At that size the 星期 label column is a dozen pixels wide, the day
#    character is 8px tall, and the day labels stop being readable — which is
#    how a table gets silently anchored to the wrong weekdays.
#
# So before any structure work: find the paper, then pick a scale whose row
# pitch is in the regime the recogniser actually resolves.

# A bright region is treated as the page only when it is neither a small patch
# nor effectively the whole frame (a plain scan has no page to find).
PAGE_REGION_MIN_FRACTION = 0.20
PAGE_REGION_MAX_FRACTION = 0.92
# How many page candidates get a full OCR pass when the crops look more promising
# than the untouched frame. The untouched frame is always the first of them. Three
# is set by the app's own budget rather than by taste: `OcrRetryPolicy.attemptTimeout`
# is 5 minutes and one full-page OCR pass measures 30-40s, so three passes plus
# structure work stays inside a single attempt. The candidate ranking below decides
# *which* crops those are, so the limit costs coverage only on an image with four
# or more genuinely different bright regions.
CANDIDATE_RECOGNITION_LIMIT = 3
# A page column/row must be at least this bright along its whole length. A dense
# timetable page still clears 0.35 because the ink is thin strokes; a strip of
# dark chrome, or a toolbar spanning only part of the height, does not.
PAGE_PROFILE_FRACTION = 0.35
# Width of the closing applied to the profile before taking the longest run. The
# page's own vertical rules are single dark pixels, so without this the run stops
# at the first printed rule and returns one column band instead of the page.
# Matches the rule width seen at this scale; a wider bridge would also swallow
# the real gap between the two tables.
PAGE_PROFILE_BRIDGE = 9
# Brightness percentile used to isolate paper. Above ~65 the dark chrome and the
# printed text both fall to the ink side while the page body stays bright.
PAGE_BRIGHT_PERCENTILE = 65

# Row pitch at or above this is read as-is: upscaling it makes the reading
# *worse*, because `_render` already normalises each crop to OCR_TARGET_HEIGHT
# and the extra resample only blurs (measured on the sample fixture: 99.0%
# native at a 15px pitch versus 95.8% forced up to 18px, 87.8% to 21px).
MIN_ROW_PITCH_PX = 14.0
# What `_scale_for_recognition` aims for below that. Measured best per page
# scale (structure native, reading scaled): a 12.8px page goes from 45.4% read
# as-is to 93.9% taken to 18px, and a 10.8px page from 50.2% to 80.6%.
RECOGNITION_TARGET_PITCH_PX = 18.0
# Hard cap on the reading upscale. `_render` normalises crops to
# OCR_TARGET_HEIGHT and itself caps at OCR_MAX_SCALE, so past ~2x the two
# resamples fight and accuracy collapses (measured 26.8% at 2.0x on a native
# page, 6.5% at 2.7x on a half-size page).
PITCH_SCALE_MAX = 1.9
# Below this native row pitch a table cannot be read reliably, whatever is done
# afterwards: upscaling cannot create detail that was never sampled. Measured on
# the sample fixture's exact geometry, the ceiling for single-mode crop reads is
# ~99% at a 15px pitch, ~80% at 10.8px and ~35% at 7.8px, and a *rendered* PDF
# page behaves the same way — on the report's own page (11px pitch), a
# transcription of the visible cells scores 61% overall: the cells the reader
# can address it reads at 97.5%, but it can only address 40 of 64 in the
# densest band, and the half-size rendering in the screenshot the user actually
# sent reaches ~4.6%.
#
# A run below this is still returned — a table to correct beats a blank screen —
# but it is flagged as unresolved, so the caller can ask for a better image
# instead of presenting wrong course names as fact. The confidence guard is
# measured: at an 11.8px pitch a crisp downscaled page still reads 95.2% at 0.956
# mean confidence and must not be flagged, while the 11.0px report screenshot
# reads 0.906 and must be. Pitch alone cannot tell those apart; pitch plus how
# confidently the cells actually read can.
UNRESOLVED_PITCH_PX = 12.0
UNRESOLVED_PITCH_CONFIDENCE = 0.95
# The other way an image can be unreadable: the pitch is fine, but the detail
# was destroyed before it got here (a thumbnail scaled back up). This measure is
# Laplacian variance over the image's own intensity variance, so it is
# *contrast-invariant* by construction, not merely scale-free: compressing the
# sample fixture's intensity range into 20..235, 48..208, 80..176 or 96..160
# leaves it at 85.47-85.50, unchanged. What it responds to is the amount of
# high-frequency detail, which is why it separates a crisp page from a blown-up
# thumbnail — and why it does *not* flag a low-contrast but genuinely crisp scan
# (that class is caught by nothing, and needs nothing: it reads fine).
#
# Measured over the sample fixture the ordering is still not the ordering of
# accuracy, so the floor is deliberately low:
#
#   image                     reads   this measure
#   0.8-sigma blur            96.6%   14.72   <- readable, was wrongly flagged at 15
#   0.9-sigma blur            81.4%    9.45
#   0.45x round trip           0.0%    6.30
#   1.0-sigma blur             0.0%    6.26
#   0.6x round trip            0.0%   15.87   <- destroyed, and *above* the readable one
#
# 8.0 sits between the lowest genuinely-readable point (9.45) and the destroyed
# ones (6.26-6.30), which is what this measure can actually be trusted for. The
# 0.6x round trip above it is caught by `UNRESOLVED_MEAN_CONFIDENCE` instead:
# an image-statistics threshold cannot separate that row from the readable ones,
# because the recogniser's own confidence is a different (and better) signal.
UNRESOLVED_SHARPNESS = 8.0
# The third way an image can be unreadable, and the one that catches what the
# pixel measures miss: the recogniser itself is guessing, which it says through
# how confidently its per-cell readings agree. This is the direct signal; the two
# pixel measures above are proxies for it and each fails on some input. 0.90 sits
# in a measured gap. Across every input in the sweep the destroyed ones read at
# most 0.873 and the readable ones at least 0.947:
#
#   destroyed (flag)     0.399-0.873   round trips 0.45x-0.70x, a 0.95-sigma
#                                      blur, the report screenshot's variants
#   readable (keep)      0.947-0.998   every benchmark accuracy variant, a
#                                      0.8-sigma blur, crisp pages to 0.80x
#
# The tightest case on each side is deliberate and quotes real numbers: a 0.70x
# round trip (37.5% correct) reads 0.873, and the `phone` variant (tilt + shadow
# + noise + JPEG, 92.2% correct) reads 0.947 — 0.074 of separation.
#
# Known residual, stated rather than hidden: a crisp page scaled to ~0.82x reads
# 82.9% at 0.930, and is *not* flagged — its confidence sits between the two
# clusters, only 0.017 below `phone`'s 0.947, so no threshold here can flag it
# without also flagging a genuinely good photo. It is in the band where the
# structure detector is the limiting factor rather than the reader, and it is
# the one scale in the sweep that lands below the target without a warning.
UNRESOLVED_MEAN_CONFIDENCE = 0.90
# When two structure scales are compared, one that found materially fewer data
# rows than another has lost part of the table and is not a candidate: at a very
# small page scale the native frame can return a handful of "rows" with gaps of
# 85px against a 15px rule pitch (the data-region streak collapsed), and those
# few, perfectly even gaps would otherwise score better than the upscale's
# honest 66 rows. 0.75 leaves room for a scale legitimately merging a couple of
# faint rows at the table's edge.
MULTISCALE_MIN_ROW_FRACTION = 0.75
# How much better the upscaled structure must score before it displaces the
# native one. 1.0 means "a strictly better score wins, ties go to native" — and
# that is the measured optimum, not a placeholder. It was 1.15 for a while, on
# the theory that the upscale is a lossy step for reading and so must *earn* the
# run; it does not. A native-preference margin is an unconditional thumb on the
# scale, and on crisp pages scaled to 0.80-0.92x it lands on the wrong frame:
# the native frame gains a spurious row boundary there (67 rows / 22 columns
# against the upscale's 66 / 22) and scores *worse*, so the margin is the only
# reason it wins. Measured on the sample fixture, same table, sweeping the page
# scale and the margin (accuracy / column count):
#
#   scale   pitch   1.15 (native wins)  1.0 (better score wins)
#   1.00    15.0px  99.0% / 22          99.0% / 22
#   0.95    14.0px  93.7% / 22          93.7% / 22
#   0.90    13.5px  49.0% / 22          96.8% / 22
#   0.88    13.0px  48.9% / 22          93.5% / 22
#   0.85    13.0px  93.9% / 22          94.9% / 22
#   0.80    12.0px  50.0% / 22          95.2% / 22
#
# 1.0 is never worse by more than the 0.85 row's 1.0 point, and it is what keeps
# a viewer-zoom screenshot readable — the exact input shape this pipeline was
# fixed for. The case that motivated 1.15 was that 0.85 row, and it no longer
# exists: the row-coverage floor plus `structure_score` now pick the better frame
# on their own merit.
MULTISCALE_UPSCALE_MARGIN = 1.0

# A tilt outside this band is treated as deliberate composition, not camera
# shake, and is left alone.
DESKEW_MIN_ANGLE = 0.3
DESKEW_MAX_ANGLE = 8.0

# Cell inset: how much of a cell border to shave off before reading it. The
# rules sit exactly on the boundary, and a slice of rule inside the crop reads
# as a stroke through the glyph, so some inset is always needed. How much is
# *not* a constant: 2px is invisible on a 15px-tall class row but eats a third
# of an 8px one, and a sliced glyph reads as nothing (measured on the sample
# fixture with the exact ground-truth geometry: the shipped fixed 2px inset
# scores 77.6% at a 15px pitch but 21.9% at 10.8px and 1.9% at 9.3px, while
# scaling the inset down recovers 69.0% and 61.4% respectively).
CROP_INSET_Y = 2
CROP_INSET_X = 3
# Above this row height the fixed inset is safe and reads best; below it the
# inset steps down so the glyph survives.
INSET_FULL_HEIGHT_PX = 13
INSET_HALF_HEIGHT_PX = 11
OCR_TARGET_HEIGHT = 48
OCR_MAX_SCALE = 6.0
OCR_MIN_SCALE = 2.0
OCR_PAD = 8

# Each cell is read under several binarisation variants and the readings are
# voted on. The variants fail differently - plain greyscale reads 生地 and 历史
# correctly while Otsu reads 电脑 correctly on the same image - so a majority
# vote is markedly more accurate than any single variant.
#
# The fourth mode is the *same* greyscale crop with a much narrower white border
# (2px rather than OCR_PAD). The recogniser resizes every crop to a fixed
# height, so a wide border shrinks the glyph inside the frame; measured on the
# sample fixture the 2px border is the strongest single rendering available
# (rot+2.5 95.6% vs 91.8% for `gray`). Adding it as a fourth vote lifts
# rot+2.5 from 97.5% to 100% and phone from 98.9% to 99.6%, with zero
# regressions on every 100% variant. The gain is more than an extra vote: it
# moves the grid's own frequency table enough that
# `vocabulary_consolidation` stops rewriting correct 体检 cells into 休检
# (measured: the erroneous `体检 -> 休检` mapping disappears entirely).
CROP_MODES = ("gray", "otsu", "color", "gray_nopad")
# White border per mode, in pixels. Modes not listed here use OCR_PAD.
CROP_MODE_PAD = {"gray_nopad": 2}
# Modes used for single-glyph *bands* (class digits, 星期 labels, merged labels),
# as opposed to whole cells. `gray_nopad` is a cell-crop variant: its 2px border
# is measured for whole cells, and `prepare_band_crop` takes no border of its
# own, so on a band `gray_nopad` is byte-identical to `gray` — including it
# would only double-count `gray`'s opinion in the band vote.
BAND_MODES = ("gray", "otsu", "color")
# A vertical crop can cut straight through the first data row, leaving that row's
# top rule outside the frame. The band above the first detected rule is then that
# row's surviving slice, and treating the image edge as its top boundary puts the
# row back: measured on the sample fixture a 13/15 slice recovers 10 of the 13
# cells the old code dropped, and vcrop6% goes from 97.5% to 100%.
#
# The band above the first rule is not always a row, so two guards:
#   * it must be a substantial slice. Below half a pitch the crop has taken the
#     glyph's top half, which is what distinguishes most characters (measured:
#     a 7/15 slice recovers nothing, a 1/15 slice is a phantom row). This is what
#     excludes a crop through the *header*, whose bottom slice measures 6/15 and
#     which otherwise shifts every day label by one.
#   * it must contain text. A blank margin above the table has none, and reading
#     it would add an empty row and renumber a whole day block.
EDGE_ROW_MIN_FRACTION = 0.5
EDGE_ROW_MIN_INK = 0.02

LOW_CONFIDENCE = 0.45
# Readings below this never enter a vote: the recogniser hallucinates short
# strings (a lone 1) on empty cells at ~0.26 confidence, and a wrong course
# name is far worse for the user than an empty cell to fill in by hand.
MIN_VOTE_CONFIDENCE = 0.30
# A cell whose text mask holds less ink than this is visually empty; cell
# readings on such crops are hallucinations of the blank input.
EMPTY_CELL_INK = 0.008
MERGED_EMPTY_MEDIAN = 0.03    # column median ink below this counts as "mostly empty"
MERGED_MAX_GLYPHS = 8         # a merged label holds at most this many glyphs
MERGED_MIN_CONFIDENCE = 0.20  # glyph reads below this are dropped as noise

# ─── vocabulary consolidation ────────────────────────────────────────────────
#
# A course cell read off a 15px row is sometimes one character off: 休检 for 体检,
# 苗语 for 英语, 数字 for 数学, 由脑 for 电脑. Those are not random noise — they are
# near-misses of a *frequent* reading, which is exactly what a timetable's own
# vocabulary makes checkable: 22 classes × 8 periods repeat the same dozen course
# names, so a reading seen once beside one seen ninety times is suspect.
#
# Two kinds of evidence, and both are needed. Measured over the sample fixture's
# eight accuracy variants (scripts/tests/decide_rule.py):
#
#   * ballot-backed — the replacement was produced from *this cell's* own pixels
#     by another binarisation variant, and recurs at least VOCAB_MIN_BACKING_RATIO
#     times as often. +42 cells, 0 lost. Cannot reach a cell whose variants all
#     agreed on the same misread.
#   * attestation-guarded — the character being replaced appears in no other
#     reading that itself recurs. Reaches those (+18 more), and that guard is
#     what keeps it off real names: 地理 is protected by 生地 (the earlier attempt
#     without it renamed 地理 to 物理 exactly where 生地 was scarce).
#
# The union ships: +60 cells, zero regressions across the whole variant matrix,
# and the same on a held-out family of degradations the thresholds were never
# tuned on (scripts/tests/holdout_check.py).
VOCAB_MIN_TARGET = 5           # a correcting reading must recur this much
VOCAB_MIN_RATIO = 1.5          # ...and beat the misread by this factor
VOCAB_MIN_BACKING_RATIO = 2.0  # ballot-backed rewrites need this factor
VOCAB_MIN_ATTEST = 2           # a character is "real" if another reading uses it
VOCAB_MAX_SOURCE = 8           # never rewrite a reading that recurs more often
VOCAB_ROUNDS = 4               # iterate to a fixed point, bounded

# A separator glyph (the / of 体锻/劳动) written vertically: a thin diagonal.
# Every other glyph band is either wide (ink in most rows) or non-monotone; a
# slash is 1-2px of ink per row drifting steadily sideways. Measured across all
# eight accuracy variants: all five 体锻/劳动 separators read maxrow ≤ 2 with a
# monotone centre drift of 4-5px over a 10px band, and no other band does.
SEPARATOR_MAX_ROW_INK = 3      # px of ink in the band's densest row
SEPARATOR_MIN_DRIFT = 3.0      # px the glyph's centre drifts across its height
SEPARATOR_MIN_HEIGHT = 5       # below this a band is a speck, not a glyph
SEPARATOR_MAX_HEIGHT = 18      # a full-height band spans two glyphs, not one

# ---------------------------------------------------------------------------
# Image loading / binarisation
# ---------------------------------------------------------------------------


def load_image(path: str) -> np.ndarray:
    """Read an image, tolerating non-ASCII paths on Windows."""
    data = np.fromfile(path, dtype=np.uint8)
    img = cv2.imdecode(data, cv2.IMREAD_COLOR)
    if img is None:
        raise FileNotFoundError(f"无法读取图片：{path}")
    return img


def binarize(gray: np.ndarray) -> np.ndarray:
    """Ink -> 255 on black background, using Otsu."""
    _, bw = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
    return bw


def binarize_adaptive(gray: np.ndarray) -> np.ndarray:
    """Ink -> 255 using a local mean threshold.

    Otsu picks one global cut, so a photo with a lighting gradient (window
    light, hand shadow) comes out half-washed-out; the local mean follows the
    illumination and keeps both the bright and the dark half usable.
    """
    block = max(11, (min(gray.shape[:2]) // 20) | 1)  # odd, ~5% of the short side
    return cv2.adaptiveThreshold(
        gray, 255, cv2.ADAPTIVE_THRESH_MEAN_C, cv2.THRESH_BINARY_INV, block, 12
    )


def sharpen(gray: np.ndarray) -> np.ndarray:
    """Mild unsharp mask.

    Fuzzy (rescaled / JPEG-compressed) photos regain stroke edges; on an
    already sharp scan the effect is small enough that binarisation is
    unaffected.
    """
    blur = cv2.GaussianBlur(gray, (0, 0), 1.0)
    return cv2.addWeighted(gray, 1.35, blur, -0.35, 0)


def normalize_scale(img: np.ndarray) -> np.ndarray:
    """Upscale very small photos so table rules stay detectable.

    Rule detection measures absolute run lengths in pixels; a timetable saved
    at thumbnail size has rules too short to pass the length thresholds even
    though the layout is fine.

    This is used to *build an extra structure candidate*, never to replace the
    image outright: upscaling smooths a 1px rule until the run-length test
    splits or drops it, so at some scales the upscaled grid is wrong where the
    native one was right (measured on the sample fixture after a 0.72x
    downscale: 22 correct boundaries at native, 33 wrong ones after this
    upscale). `detect_structure_multiscale` measures both and keeps the better.
    """
    smallest = min(img.shape[:2])
    if smallest >= MIN_PROCESS_DIM:
        return img
    factor = min(3.0, MIN_PROCESS_DIM / smallest)
    return cv2.resize(img, None, fx=factor, fy=factor, interpolation=cv2.INTER_CUBIC)


def _longest_page_run(profile: np.ndarray, minimum: float,
                      bridge: int = PAGE_PROFILE_BRIDGE) -> Optional[Tuple[int, int]]:
    """Longest contiguous run of entries at or above `minimum`, thin gaps bridged.

    Two things make a naive first-to-last-index span wrong, and the run form
    fixes both.

    Contiguity: on a rotated screenshot the extra white margin the rotation adds
    and the page itself are both bright, and a first/last span then covers the
    whole frame, fails the frame-fraction test, and finds no page at all.

    Bridging: the page's own vertical rules are one dark pixel wide, so a column
    profile of a real timetable page is bright, dark, bright, … — taking the
    longest run without bridging would stop at the first printed rule and return
    one column band instead of the page (measured: the 549px-wide page came back
    as a 135px strip). `bridge` closes gaps of that width.
    """
    qualified = (profile >= minimum).astype(np.uint8)
    if bridge > 1:
        qualified = cv2.morphologyEx(
            qualified.reshape(1, -1), cv2.MORPH_CLOSE,
            cv2.getStructuringElement(cv2.MORPH_RECT, (bridge, 1)),
        ).reshape(-1)

    best_start = best_len = 0
    start = None
    for index, value in enumerate(qualified):
        if value:
            if start is None:
                start = index
            length = index - start + 1
            if length > best_len:
                best_len, best_start = length, start
        else:
            start = None
    if best_len < 2:
        return None
    return best_start, best_start + best_len - 1


def _bright_region(img: np.ndarray, percentile: int, min_fraction: float,
                   bridge: int) -> Optional[Tuple[int, int, int, int]]:
    """Bounding box of the largest bright band, using one threshold recipe."""
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    height, width = gray.shape[:2]
    if height * width == 0:
        return None

    # The 180 floor keeps dark application chrome on the ink side. It must not
    # be allowed to reach the image's own brightest level, though: on a
    # screenshot whose page body is pure white (255) `np.percentile` returns 255
    # and the local threshold becomes "brighter than white", so the recipe
    # returns None and the crop list loses the page exactly on the input it was
    # written for. Measured: a white page on dark chrome gives pct65=255, and at
    # a 0.91 frame fraction even pct50=255 — every recipe collapses and the
    # fallback list is the untouched frame alone.
    threshold = max(int(np.percentile(gray, percentile)), 180)
    brightest = int(gray.max())
    if threshold >= brightest:
        threshold = brightest - 1
    bright = gray > threshold
    columns = _longest_page_run(bright.mean(axis=0), PAGE_PROFILE_FRACTION, bridge)
    rows = _longest_page_run(bright.mean(axis=1), PAGE_PROFILE_FRACTION, bridge)
    if columns is None or rows is None:
        return None

    x, x2 = columns
    y, y2 = rows
    w, h = x2 - x + 1, y2 - y + 1
    fraction = (w * h) / float(height * width)
    if fraction < min_fraction:
        return None
    # A region that is effectively the whole frame is not a page inside a
    # screenshot — it is a plain scan, and the caller already has the untouched
    # frame first. `page_candidates` would drop it anyway, so this only saves
    # the work and keeps the constant's promise.
    if fraction > PAGE_REGION_MAX_FRACTION:
        return None
    if w < 32 or h < 32:
        return None
    return x, y, w, h


def page_candidates(
    img: np.ndarray,
) -> List[Tuple[np.ndarray, Optional[Tuple[int, int, int, int]]]]:
    """Crops worth trying, best first: the whole frame, then bright regions.

    The whole frame comes first so that an image which already *is* the page is
    never cropped — the caller tries candidates in order and stops at the first
    one whose structure detection succeeds, so a plain scan (the common case)
    behaves exactly as before and no heuristic can lose a table that used to be
    found.

    The extra candidates exist for images where the timetable is only part of the
    frame. Those fail for a reason unrelated to the table: `binarize` is a global
    Otsu threshold, so a dark application border around the page reads as ink — a
    real viewer screenshot came out 64% ink — and the horizontal rule measurement
    dies with it. Several threshold recipes are offered rather than one because
    how much of the frame the page occupies, and how dark the surroundings are,
    both vary; the caller's structure check is what decides, so an over-eager
    recipe costs one failed attempt and nothing else.
    """
    candidates: List[Tuple[np.ndarray, Optional[Tuple[int, int, int, int]]]] = [(img, None)]
    recipes = (
        (PAGE_BRIGHT_PERCENTILE, PAGE_REGION_MIN_FRACTION, PAGE_PROFILE_BRIDGE),
        (50, 0.15, PAGE_PROFILE_BRIDGE),
        (50, 0.15, 5),
        (80, 0.10, 5),
    )
    seen: set = set()
    for percentile, min_fraction, bridge in recipes:
        region = _bright_region(img, percentile, min_fraction, bridge)
        if region is None or region in seen:
            continue
        seen.add(region)
        x, y, w, h = region
        if w >= img.shape[1] and h >= img.shape[0]:
            continue
        candidates.append((img[y:y + h, x:x + w], region))
    return candidates



def median_row_pitch(rows: Sequence[Tuple[int, int]]) -> float:
    """Median centre-to-centre distance of consecutive data rows, in pixels."""
    if len(rows) < 2:
        return 0.0
    centres = [(top + bottom) / 2.0 for top, bottom in rows]
    gaps = [centres[i + 1] - centres[i] for i in range(len(centres) - 1)]
    return float(np.median(gaps))


def _scale_for_recognition(
    img: np.ndarray,
    xs: Sequence[int],
    header: Sequence[int],
    rows: Sequence[Tuple[int, int]],
) -> Tuple[np.ndarray, List[int], List[int], List[Tuple[int, int]]]:
    """Enlarge the image until a class row is as tall as the recogniser wants.

    Only the *recognition* image is scaled; the geometry was measured at native
    resolution (see `_recognize_frame`) and is mapped into the new frame, so a
    blur introduced here cannot move a boundary.

    The target is a row pitch of `RECOGNITION_TARGET_PITCH_PX`, not the bare
    `MIN_ROW_PITCH_PX` floor, and it was picked by measurement rather than
    preference. Sweeping the target over the sample fixture's exact geometry
    (structure native, reading scaled) gives, per page scale:

        page 1.00x (pitch 15.0):  target 15 -> 99.0%, 18 -> 95.8%, 21 -> 87.8%
        page 0.85x (pitch 12.8):  target 15 -> 88.4%, 18 -> 93.9%, 21 -> 49.2%
        page 0.72x (pitch 10.8):  target 15 -> 61.0%, 18 -> 80.6%, 21 -> 70.7%

    so a page already at or above the floor is left alone (nothing beats the
    native reading) and a smaller page is taken straight to ~18px rather than
    merely over the floor.

    The cap matters more than it looks: `_render` normalises every crop to
    `OCR_TARGET_HEIGHT` and itself caps at `OCR_MAX_SCALE`, so blowing a page
    up past ~2x makes the two resamples fight and accuracy collapses (measured:
    26.8% at a 2.0x factor on the native page, 6.5% at 2.7x on a 0.72x page
    where the ceiling of the double resample is reached).
    """
    pitch = median_row_pitch(rows)
    if pitch <= 0 or pitch >= MIN_ROW_PITCH_PX:
        return img, list(xs), list(header), list(rows)

    factor = min(PITCH_SCALE_MAX, RECOGNITION_TARGET_PITCH_PX / pitch)
    if factor <= 1.02:
        return img, list(xs), list(header), list(rows)

    scaled = cv2.resize(img, None, fx=factor, fy=factor, interpolation=cv2.INTER_CUBIC)
    scale = lambda value: int(round(value * factor))  # noqa: E731 - local shorthand
    return (
        scaled,
        [scale(v) for v in xs],
        [scale(v) for v in header],
        [(scale(top), scale(bottom)) for top, bottom in rows],
    )


def estimate_skew(bw: np.ndarray) -> float:
    """Median tilt of long ink strokes, in degrees relative to the nearest axis.

    Both vertical and horizontal rules contribute: their deviations from 0°/90°
    agree when the whole photo is tilted, which is exactly the case worth
    correcting. Text rows are shorter than `minLineLength` and do not vote.
    """
    scale = min(1.0, 1200.0 / max(bw.shape[0], bw.shape[1]))
    small = cv2.resize(bw, None, fx=scale, fy=scale, interpolation=cv2.INTER_AREA) \
        if scale < 1.0 else bw
    lines = cv2.HoughLinesP(
        small, 1, np.pi / 720, threshold=100,
        minLineLength=min(small.shape[0], small.shape[1]) // 5, maxLineGap=5,
    )
    if lines is None:
        return 0.0
    deviations = []
    for x1, y1, x2, y2 in lines.reshape(-1, 4):
        angle = np.degrees(np.arctan2(float(y2 - y1), float(x2 - x1)))
        deviations.append((angle + 45.0) % 90.0 - 45.0)
    return float(np.median(deviations)) if deviations else 0.0


def rotate_image(img: np.ndarray, degrees: float, nearest: bool = False) -> np.ndarray:
    """Rotate content by `degrees` counter-clockwise, growing the canvas.

    `nearest` keeps a binary mask binary: rules resampled with INTER_CUBIC turn
    fuzzy and stop lining up in crisp 1-2px runs, which is what structure
    detection measures.
    """
    h, w = img.shape[:2]
    matrix = cv2.getRotationMatrix2D((w / 2, h / 2), degrees, 1.0)
    cos, sin = abs(matrix[0, 0]), abs(matrix[0, 1])
    new_w, new_h = int(h * sin + w * cos), int(h * cos + w * sin)
    matrix[0, 2] += new_w / 2 - w / 2
    matrix[1, 2] += new_h / 2 - h / 2
    fill = 0 if nearest else 255
    return cv2.warpAffine(
        img, matrix, (new_w, new_h),
        flags=cv2.INTER_NEAREST if nearest else cv2.INTER_CUBIC,
        borderValue=(fill, fill, fill) if img.ndim == 3 else fill,
    )


def text_only_mask(bw: np.ndarray) -> np.ndarray:
    """Remove long straight rules so only glyphs remain."""
    h_lines = cv2.morphologyEx(
        bw, cv2.MORPH_OPEN, cv2.getStructuringElement(cv2.MORPH_RECT, (25, 1))
    )
    v_lines = cv2.morphologyEx(
        bw, cv2.MORPH_OPEN, cv2.getStructuringElement(cv2.MORPH_RECT, (1, 15))
    )
    rules = cv2.dilate(cv2.bitwise_or(h_lines, v_lines), np.ones((3, 3), np.uint8))
    return cv2.bitwise_and(bw, cv2.bitwise_not(rules))


# ---------------------------------------------------------------------------
# Small 1-D helpers
# ---------------------------------------------------------------------------


def group_values(values: Sequence[int], gap: int = RULE_GAP_PX) -> List[int]:
    """Collapse runs of nearby coordinates into their mean position."""
    if not values:
        return []
    out: List[int] = []
    cur = [values[0]]
    for v in values[1:]:
        if v - cur[-1] <= gap:
            cur.append(v)
        else:
            out.append(int(round(float(np.mean(cur)))))
            cur = [v]
    out.append(int(round(float(np.mean(cur)))))
    return out


def find_runs(mask_1d: np.ndarray, min_len: int) -> List[Tuple[int, int]]:
    """Return (start, end) runs of truthy values at least `min_len` long."""
    runs: List[Tuple[int, int]] = []
    start = None
    for i, v in enumerate(mask_1d):
        if v:
            if start is None:
                start = i
        elif start is not None:
            if i - start >= min_len:
                runs.append((start, i))
            start = None
    if start is not None and len(mask_1d) - start >= min_len:
        runs.append((start, len(mask_1d)))
    return runs


# ---------------------------------------------------------------------------
# Structure detection
# ---------------------------------------------------------------------------


def _longest_run_per_column(mask: np.ndarray) -> np.ndarray:
    """Longest run of True in each column, vectorised over rows.

    A pure-Python per-column loop is O(W*H) with a very large constant, which is
    noticeable on big scans; doing one vectorised step per row is far cheaper.
    """
    longest = np.zeros(mask.shape[1], dtype=np.int32)
    run = np.zeros(mask.shape[1], dtype=np.int32)
    for y in range(mask.shape[0]):
        run = np.where(mask[y], run + 1, 0)
        np.maximum(longest, run, out=longest)
    return longest


def _longest_run_per_row(mask: np.ndarray) -> np.ndarray:
    """Longest run of True in each row, vectorised over columns."""
    longest = np.zeros(mask.shape[0], dtype=np.int32)
    run = np.zeros(mask.shape[0], dtype=np.int32)
    for x in range(mask.shape[1]):
        run = np.where(mask[:, x], run + 1, 0)
        np.maximum(longest, run, out=longest)
    return longest


def detect_vertical_rules(
    bw: np.ndarray, min_fraction: float = V_RULE_RUN_FRACTION,
    min_width: int = 1, close_h: int = 3,
) -> List[int]:
    """x positions of long vertical rules.

    `min_width` filters detected columns by the width of the run cluster they
    belong to. On deskewed photos rules are deliberately thickened before the
    measurement (nearest-neighbour rotation of a 1px rule shreds it into a
    staircase); a thick rule is several columns wide, while dilated text
    produces clusters only 1-3 columns wide, so width is what separates them.

    `close_h` is the vertical closing that bridges dotted rules.
    """
    height = bw.shape[0]
    closed = cv2.morphologyEx(
        bw, cv2.MORPH_CLOSE, cv2.getStructuringElement(cv2.MORPH_RECT, (1, close_h))
    )
    min_run = max(10, int(min_fraction * height))
    longest = _longest_run_per_column(closed > 0)
    columns = [x for x in range(bw.shape[1]) if longest[x] >= min_run]
    if not columns:
        return []
    clusters: List[List[int]] = [[columns[0]]]
    for x in columns[1:]:
        if x - clusters[-1][-1] <= RULE_GAP_PX:
            clusters[-1].append(x)
        else:
            clusters.append([x])
    return [
        int(round(float(np.mean(cluster))))
        for cluster in clusters
        if cluster[-1] - cluster[0] + 1 >= min_width
    ]


def _column_gaps_sane(xs: Sequence[int], max_ratio: float = 2.2) -> bool:
    """Whether the widest gap between boundaries is plausible for this table.

    Timetable columns are near-uniform in width. A missed rule cluster — the
    typical deskew artifact — shows up as one gap several times the median
    width, which is the signal that stricter attempts should not be trusted
    and a more tolerant one is worth trying. Slight width variance (the narrow
    星期 column) stays well under the ratio.
    """
    if len(xs) < 3:
        return True
    gaps = [b - a for a, b in zip(xs, xs[1:])]
    median_gap = float(np.median(gaps))
    return median_gap > 0 and max(gaps) <= max_ratio * median_gap


def structure_score(xs: Sequence[int], rows: Sequence[Tuple[int, int]]) -> Optional[float]:
    """How plausible a detected grid is, lower being better; None when unusable.

    One number, so that two working scales can be compared. The dominant term is
    *column* uniformity, measured the same way `_column_gaps_sane` measures it:
    a spurious or missed vertical rule shows up as one gap several times the
    median, which is exactly what a lossy upscale produces (measured on the
    sample fixture after a 0.72x downscale: the native frame gives 22 boundaries
    with a 1.11 gap ratio, the upscaled one 33 boundaries with 2.0 — the extra
    boundaries are the blurred rules splitting, and every cell after them is
    off by one). Row uniformity guards the other axis: a data region truncated
    mid-table leaves one enormous "row" (measured 85px against a 15px median).
    """
    if len(xs) < 4 or len(rows) < 4:
        return None
    column_gaps = [b - a for a, b in zip(xs, xs[1:])]
    median_column = float(np.median(column_gaps))
    if median_column <= 0:
        return None
    centres = [(top + bottom) / 2.0 for top, bottom in rows]
    row_gaps = [centres[i + 1] - centres[i] for i in range(len(centres) - 1)]
    median_row = float(np.median(row_gaps))
    if median_row <= 0:
        return None
    column_dev = max(column_gaps) / median_column
    row_dev = max(abs(gap - median_row) for gap in row_gaps) / median_row
    return 2.0 * column_dev + row_dev


def pad_outer_boundaries(xs: List[int], bw: np.ndarray) -> List[int]:
    """Add the table's outer border when it was not drawn as a rule.

    The sample image's left table starts at the very edge of the bitmap, so no
    vertical rule is detected there; without a left boundary the 星期 column
    would be lost. On photos the outer rules also vanish into the margin left
    by deskewing, so any ink run of a plausible column width lying left/right
    of the outermost detected rule gets a boundary.
    """
    if len(xs) < 2:
        return xs
    typical = float(np.median([xs[i + 1] - xs[i] for i in range(len(xs) - 1)]))
    min_gap = max(3, int(0.15 * typical))
    ink_cols = np.where((bw > 0).sum(axis=0) > 0)[0]
    out = list(xs)
    if ink_cols.size and xs[0] - int(ink_cols[0]) >= min_gap:
        out.insert(0, max(0, int(ink_cols[0]) - 1))
    if ink_cols.size and int(ink_cols[-1]) - xs[-1] >= min_gap:
        out.append(min(bw.shape[1] - 1, int(ink_cols[-1]) + 1))
    return out


def detect_horizontal_rules(bw: np.ndarray, x1: int, x2: int,
                            v_bridge: int = 1) -> List[int]:
    """y positions of horizontal rules inside the x-range, bridging dotted lines.

    Rules are not assumed to span the whole x-range: a side-by-side layout has
    each table's rules broken at the gap between them. Instead we measure the
    longest ink run on every row and keep the rows whose run is close to the
    longest run seen anywhere, which adapts to however wide the widest rule is.

    A row of tightly-spaced text can also look like one long run once the
    closing has bridged the gaps between glyphs, so a candidate must also be
    solid: nearly all of its raw ink belongs to that single run.

    `v_bridge` dilates vertically before measuring: deskewed photo rules wobble
    a few pixels up and down, which smears each row's run across neighbours and
    starves the run-length measurement — exactly the horizontal twin of what
    `bridge_w` does for vertical rules.
    """
    sub = bw[:, x1:x2]
    width = sub.shape[1]
    if v_bridge > 1:
        sub = cv2.dilate(sub, cv2.getStructuringElement(cv2.MORPH_RECT, (1, v_bridge)))
    raw_ink = (sub > 0).sum(axis=1).astype(np.int32)

    # Three passes, increasingly tolerant. The strict one targets solid rules;
    # the wider ones catch genuinely dotted rules and then blurred photo rules
    # (whose raw ink is only their duty cycle). A later pass only runs when the
    # earlier ones found nothing at all, so a table with solid rules is never
    # disturbed by text rows that closing happens to merge.
    #
    # "First pass that finds anything" is deliberate, and keeping the *most*
    # rows instead was tried and reverted: an over-tolerant pass does not merge
    # rules, it starts counting text rows at about half the true pitch, so
    # preferring volume there hands the whole table to the text counter
    # (measured: it took the report screenshot from 345 filled cells to 32, and
    # rot+1.0 on the sample fixture from 95.2% to 1.0%).
    for kernel, solidity in ((9, 0.8), (15, 0.5), (27, 0.32)):
        closed = cv2.morphologyEx(
            sub, cv2.MORPH_CLOSE, cv2.getStructuringElement(cv2.MORPH_RECT, (kernel, 1))
        )
        longest = _longest_run_per_row(closed > 0)
        peak = int(longest.max())
        if peak <= 0:
            continue
        threshold = max(30, int(0.6 * peak), int(0.15 * width))
        rows = [
            y for y in range(sub.shape[0])
            if longest[y] >= threshold and raw_ink[y] >= solidity * longest[y]
        ]
        if rows:
            return group_values(rows)
    return []


def _band_holds_text(mask: Optional[np.ndarray], height: int,
                     x1: int, x2: Optional[int]) -> bool:
    """Whether the band `[0, height)` of `mask` carries text ink.

    `mask` is the binarisation the rules were measured on (ink is 255), and the
    band sits above the first rule, so no rule runs through it: what is left is
    glyphs. A blank margin above the table has none, and must not be mistaken for
    a cut-off row. Without a mask there is nothing to check, and the geometric
    guard alone is allowed to decide.
    """
    if mask is None or height <= 0:
        return True
    hi = mask.shape[1] if x2 is None else min(int(x2), mask.shape[1])
    lo = max(0, int(x1))
    if hi <= lo or height > mask.shape[0]:
        return False
    return float((mask[0:height, lo:hi] > 0).mean()) >= EDGE_ROW_MIN_INK


def find_data_rows(ys: Sequence[int], *, mask: Optional[np.ndarray] = None,
                   x1: int = 0, x2: Optional[int] = None
                   ) -> Tuple[List[int], List[Tuple[int, int]]]:
    """Split horizontal boundaries into (header boundaries, data row bounds).

    The data region is the longest run of consecutive gaps that match the
    dominant row pitch. Everything above it is header.

    A few row separators always vanish on photos (light print, resampling), so
    gaps that are a whole multiple of the pitch are pre-repaired with
    synthesised boundaries before the streak is measured — one faint rule used
    to truncate the data region and drop twenty rows in the middle of the
    table. Gaps that are *not* pitch-like (the header's taller bands, the title
    rule) are never bridged, which is what keeps the header out of the data
    region.
    """
    if len(ys) < 3:
        return list(ys), []
    gaps = [ys[i + 1] - ys[i] for i in range(len(ys) - 1)]

    # Dominant pitch among the smaller gaps (header gaps are usually larger).
    counts = Counter(g for g in gaps if g > 0)
    pitch = None
    for value, _ in counts.most_common():
        pitch = value
        break
    if not pitch:
        return list(ys), []

    # Header rows are usually a little taller than data rows, so the tolerance
    # has to be tight enough not to swallow them.
    slack = max(2.0, pitch * PITCH_TOLERANCE)
    lo, hi = pitch - slack, pitch + slack

    # Pre-repair across missing rules (1-3 of them), but only where the gap is
    # a clean multiple of the pitch.
    repaired = [ys[0]]
    for y in ys[1:]:
        gap = y - repaired[-1]
        n_missing = int(round(gap / pitch)) - 1
        if lo < gap and 1 <= n_missing <= 3 and abs(gap - (n_missing + 1) * pitch) <= 2.2 * hi:
            for k in range(1, n_missing + 1):
                repaired.append(repaired[-1] + pitch)
        repaired.append(y)

    is_row_gap = [lo <= (b - a) <= hi for a, b in zip(repaired, repaired[1:])]
    best_start = best_len = cur_start = cur_len = 0
    for i, ok in enumerate(is_row_gap):
        if ok:
            if cur_len == 0:
                cur_start = i
            cur_len += 1
            if cur_len > best_len:
                best_len, best_start = cur_len, cur_start
        else:
            cur_len = 0

    if best_len < 2:
        return list(ys), []

    # A vertical crop can cut straight through the first data row, leaving that
    # row's top rule outside the frame. The surviving sliver then sits above the
    # first detected rule and is silently dropped — and with it a whole class
    # row: measured on the sample fixture's 6% vertical crop, both tables lose
    # class 1 (13 ground-truth cells), because the 班 column's digits read 2..22
    # and `_block_class_numbers` takes that clean run at face value. The sliver
    # itself is still readable: re-reading those cells recovers 10 of the 13.
    #
    # So treat the image's own top edge as that row's top boundary. The guard is
    # `best_start == 0`: the data region really does begin at the image's first
    # rule, so the band above it is bounded by the frame edge and not by a real
    # rule — a crop through the *header* leaves a rule above the band, so it does
    # not match. `_band_holds_text` and the half-pitch floor do the rest; see
    # `EDGE_ROW_MIN_FRACTION`.
    #
    # The bottom edge is deliberately not treated symmetrically: a partial row
    # there is not what any measured input loses, and a misread class digit in it
    # would renumber a whole day block.
    if best_start == 0 and 0 < repaired[0] <= pitch \
            and repaired[0] >= pitch * EDGE_ROW_MIN_FRACTION \
            and _band_holds_text(mask, repaired[0], x1, x2):
        repaired.insert(0, 0)
        # The synthesised boundary is a row boundary by construction; the streak
        # above must see it as one or the sliver is dropped again.
        is_row_gap = [True] + is_row_gap
        best_start = 0

    # Include the first data row's top boundary so the last header band is
    # bounded below as well.
    first_data = repaired[best_start]
    header = [y for y in repaired if y < first_data] + [first_data]
    rows = [(repaired[k], repaired[k + 1])
            for k in range(best_start, len(repaired) - 1)]
    return header, rows


# ---------------------------------------------------------------------------
# OCR engines
# ---------------------------------------------------------------------------


class OcrEngine:
    """Batched, detection-free text recognition over known cell crops."""

    name = "base"

    def recognize(self, crops: Sequence[np.ndarray]) -> List[Tuple[str, float]]:
        raise NotImplementedError


class RapidOcrEngine(OcrEngine):
    """RapidOCR (PP-OCRv3) — recognition model only, batched.

    Text detection is deliberately skipped: the grid already tells us exactly
    where each cell is, and detection on ~40x15px cells is both slow (~2.4s per
    cell) and unreliable. Feeding the crops straight to the recogniser is
    ~500x faster and finds markedly more text.
    """

    name = "rapidocr"

    def __init__(self) -> None:
        from rapidocr_onnxruntime import RapidOCR  # noqa: WPS433 (optional dep)

        self._engine = RapidOCR()
        self._rec = getattr(self._engine, "text_recognizer", None)
        if self._rec is None:
            raise RuntimeError(
                "当前 rapidocr_onnxruntime 版本不支持批量识别接口（text_recognizer）"
            )

    def recognize(self, crops: Sequence[np.ndarray]) -> List[Tuple[str, float]]:
        if not len(crops):
            return []
        results, _ = self._rec(list(crops))
        out: List[Tuple[str, float]] = []
        for item in results:
            text, score = (item[0], item[1]) if len(item) == 2 else (item[1], item[2])
            out.append((text or "", float(score)))
        return out


class RapidOcrV6Engine(OcrEngine):
    """RapidOCR 3.x (PP-OCRv6 rec) — recognition model only, batched.

    Same detection-free contract as `RapidOcrEngine` on a much newer
    recogniser: v6 reads blurred photo cells (rotation, JPEG noise, rescaling)
    markedly better than the v3 model bundled with rapidocr_onnxruntime.
    Returns one (text, score) per input crop, order preserved, empty reads as
    ("", 0.0).
    """

    name = "rapidocr3"

    def __init__(self) -> None:
        from rapidocr import RapidOCR  # noqa: WPS433 (optional dep)
        from rapidocr.ch_ppocr_rec.typings import TextRecInput  # noqa: WPS433

        # 单线程 ONNX 会话：我们的批量识别自带并行（一次喂几百个裁剪），
        # 会话内多线程只会白白多占几份线程内存——低内存机器上正是这份
        # 额外分配让模型加载直接失败。
        self._engine = RapidOCR(params={
            "Det.intra_op_num_threads": 1,
            "Det.inter_op_num_threads": 1,
            "Cls.intra_op_num_threads": 1,
            "Rec.intra_op_num_threads": 1,
            "Rec.inter_op_num_threads": 1,
        })
        self._args = TextRecInput

    def recognize(self, crops: Sequence[np.ndarray]) -> List[Tuple[str, float]]:
        if not len(crops):
            return []
        out = self._engine.text_rec(self._args(img=list(crops)))
        txts = tuple(out.txts or ())
        scores = tuple(out.scores or ())
        results: List[Tuple[str, float]] = []
        for i in range(len(crops)):
            text = txts[i] if i < len(txts) else ""
            score = scores[i] if i < len(scores) else 0.0
            results.append((text or "", float(score or 0.0)))
        return results


class TesseractEngine(OcrEngine):
    """Fallback engine. Much weaker on tiny Chinese glyphs, but dependency-light."""

    name = "tesseract"

    def __init__(self) -> None:
        import pytesseract  # noqa: WPS433 (optional dep)

        self._pytesseract = pytesseract
        for candidate in (
            os.environ.get("TESSERACT_CMD"),
            r"C:\Program Files\Tesseract-OCR\tesseract.exe",
            r"C:\Program Files (x86)\Tesseract-OCR\tesseract.exe",
        ):
            if candidate and os.path.exists(candidate):
                pytesseract.pytesseract.tesseract_cmd = candidate
                break
        for tessdata in (
            os.environ.get("TESSDATA_PREFIX"),
            os.path.expanduser(r"~\tessdata"),
            r"C:\Program Files\Tesseract-OCR\tessdata",
        ):
            if tessdata and os.path.isdir(tessdata):
                os.environ["TESSDATA_PREFIX"] = tessdata
                break

    def recognize(self, crops: Sequence[np.ndarray]) -> List[Tuple[str, float]]:
        out: List[Tuple[str, float]] = []
        for crop in crops:
            try:
                text = self._pytesseract.image_to_string(
                    crop, lang="chi_sim", config="--psm 7"
                ).strip()
            except Exception:
                text = ""
            out.append((text, 1.0 if text else 0.0))
        return out


def create_engine(prefer: Optional[str] = None) -> OcrEngine:
    """Instantiate the best available OCR engine."""
    order = [prefer] if prefer else []
    order += [e for e in ("rapidocr3", "rapidocr", "tesseract") if e not in order]
    errors = []
    for name in order:
        try:
            if name == "rapidocr3":
                return RapidOcrV6Engine()
            if name == "rapidocr":
                return RapidOcrEngine()
            if name == "tesseract":
                return TesseractEngine()
        except Exception as exc:  # pragma: no cover - environment dependent
            errors.append(f"{name}: {exc}")
    raise RuntimeError(
        "没有可用的 OCR 引擎，请安装 rapidocr（推荐）或 rapidocr-onnxruntime / pytesseract。"
        " 详情：" + "; ".join(errors)
    )


# ---------------------------------------------------------------------------
# Cell cropping
# ---------------------------------------------------------------------------


def _render(roi: np.ndarray, mode: str, pad: int = OCR_PAD) -> np.ndarray:
    """Upscale, pad and binarise a crop according to `mode`; returns 3 channels.

    `pad` is the width of the white border. It is a per-mode setting rather than
    a constant because the recogniser resamples every crop to a fixed height, so
    the border takes space away from the glyph: 2px measures better than 8px for
    the greyscale mode (see `CROP_MODES`), while the binarised modes are tuned
    around `OCR_PAD`.
    """
    scale = min(OCR_MAX_SCALE, max(OCR_MIN_SCALE, OCR_TARGET_HEIGHT / max(roi.shape[0], 1)))
    big = cv2.resize(roi, None, fx=scale, fy=scale, interpolation=cv2.INTER_CUBIC)
    # Unsharp mask at the recogniser's own scale: deskewed photos arrive with
    # softly blurred strokes, and the resample to ~48px does not restore edge
    # contrast. Sharpening here fixes that; on already-crisp scans the effect
    # is below the noise floor of the recogniser.
    big = cv2.addWeighted(big, 1.4, cv2.GaussianBlur(big, (0, 0), 1.2), -0.4, 0)
    big = cv2.copyMakeBorder(big, pad, pad, pad, pad,
                             cv2.BORDER_CONSTANT, value=255)
    if mode == "color":
        return big
    grey = cv2.cvtColor(big, cv2.COLOR_BGR2GRAY)
    if mode == "otsu":
        _, grey = cv2.threshold(grey, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    # The recogniser expects 3 channels.
    return cv2.cvtColor(grey, cv2.COLOR_GRAY2BGR)


def _cell_inset(height: int, width: int,
                inset_y: int = CROP_INSET_Y,
                inset_x: int = CROP_INSET_X) -> Tuple[int, int]:
    """How much of a cell's border to shave before reading it.

    The printed rules lie on the cell boundary, and a slice of rule inside the
    crop reads as a stroke through the glyph — so some inset is always needed.
    A fixed inset is only safe while the cell is tall: 2px is invisible on a
    15px class row and eats a third of an 8px one, and a sliced glyph reads as
    nothing at all. Below `INSET_FULL_HEIGHT_PX` the vertical inset therefore
    steps down with the row height (measured on the sample fixture with exact
    geometry: 77.6% at a 15px pitch, but 21.9% at 10.8px with the fixed inset
    versus 52.1% with the adaptive one, and 1.9% versus 16.9% at 9.3px).

    A quarter of the row is the step floor: below that the rule slice is inside
    the crop again and the reading gets worse, not better.

    The step is deliberately **not** monotone in row height, and that is measured
    rather than an oversight. Thresholds give 2px at 10px and 1px at 11px, i.e. the
    inset grows as the cell shrinks. Capping the small-row branch at the half value
    to make the step monotone was tried and costs 23.8 points on the sample
    fixture's 1.0° rotation: 97.9% with the step as it is, 74.1% capped. Logging
    every call on that input shows why the cap is felt at all when the data rows
    are 16px — the differing calls are all on 10px bands and merged-cell bands
    (138 calls at h=10 against 4,727 total), and shrinking their inset to 1px
    leaves the rule inside the crop. The reviewer's reading of the code was right
    (the branch is non-monotone) and the direction it implies is wrong; this is the
    measurement that settles it.
    """
    if height >= INSET_FULL_HEIGHT_PX:
        iy = inset_y
    elif height >= INSET_HALF_HEIGHT_PX:
        iy = max(1, inset_y // 2)
    else:
        iy = max(1, height // 4)
    # Columns are wide enough that the horizontal inset is never the binding
    # constraint on glyph survival; only guard against eating the whole column.
    ix = min(inset_x, max(0, (width - 2) // 2))
    return min(iy, max(0, (height - 2) // 2)), ix


def prepare_crop(img: np.ndarray, y1: int, y2: int, x1: int, x2: int,
                 mode: str = "gray") -> np.ndarray:
    """Crop one cell, upscale it and pad with white so the recogniser can read it."""
    iy, ix = _cell_inset(y2 - y1, x2 - x1)
    cy1 = max(0, y1 + iy)
    cy2 = min(img.shape[0], y2 - iy)
    cx1 = max(0, x1 + ix)
    cx2 = min(img.shape[1], x2 - ix)
    if cy2 <= cy1 or cx2 <= cx1:
        return np.full((16, 40, 3), 255, np.uint8)
    # `gray_nopad` is the same greyscale crop with a narrower white border — a
    # fourth vote, not a replacement for `gray`, so the binarisation mode is
    # resolved from the vote name and only the border differs.
    binarise = mode if mode in ("otsu", "color") else "gray"
    return _render(img[cy1:cy2, cx1:cx2], binarise,
                   pad=CROP_MODE_PAD.get(mode, OCR_PAD))


def prepare_band_crop(img: np.ndarray, y1: int, y2: int, x1: int, x2: int,
                      pad_y: int = 4, pad_x: int = 1, mode: str = "gray") -> np.ndarray:
    """Crop a glyph band (not a full cell) with a little padding around it.

    Cell insets would shave a 10px band down to 6px and cut the glyph, so bands
    get padding instead.
    """
    cy1 = max(0, y1 - pad_y)
    cy2 = min(img.shape[0], y2 + pad_y)
    cx1 = max(0, x1 - pad_x)
    cx2 = min(img.shape[1], x2 + pad_x)
    if cy2 <= cy1 or cx2 <= cx1:
        return np.full((24, 40, 3), 255, np.uint8)
    return _render(img[cy1:cy2, cx1:cx2], mode)


def ink_ratio(mask: np.ndarray, y1: int, y2: int, x1: int, x2: int) -> float:
    """Fraction of text pixels inside a cell."""
    iy, ix = _cell_inset(y2 - y1, x2 - x1)
    cy1 = max(0, y1 + iy)
    cy2 = min(mask.shape[0], y2 - iy)
    cx1 = max(0, x1 + ix)
    cx2 = min(mask.shape[1], x2 - ix)
    if cy2 <= cy1 or cx2 <= cx1:
        return 0.0
    roi = mask[cy1:cy2, cx1:cx2]
    return float((roi > 0).sum()) / float(roi.size)


# ---------------------------------------------------------------------------
# Text post-processing
# ---------------------------------------------------------------------------

_STRIP_CHARS = set(" \t\r\n,，.。、;；:：|｜/／\\-—_~·'\"“”‘’()（）[]【】<>《》")


def _is_meaningful(ch: str) -> bool:
    if ch.isalnum():
        return True
    code = ord(ch)
    return 0x4E00 <= code <= 0x9FFF or 0x3400 <= code <= 0x4DBF


def clean_text(raw: str) -> str:
    """Normalise raw OCR output into a bare course name."""
    if not raw:
        return ""
    text = unicodedata.normalize("NFKC", raw)
    text = "".join(ch for ch in text if ch not in _STRIP_CHARS)
    text = "".join(ch for ch in text if _is_meaningful(ch))
    return text.strip()


def _one_char_apart(a: str, b: str) -> Tuple[int, int]:
    """(kind, position) of how `a` could be a misread of `b`.

    1 — same length, exactly one character differs (休检 → 体检).
    2 — `a` is a truncation of `b` (学 → 数学), i.e. a crop lost a character.
    0 — unrelated, and so not a candidate for consolidation.
    """
    if len(a) == len(b):
        diff = [i for i in range(len(a)) if a[i] != b[i]]
        return (1, diff[0]) if len(diff) == 1 else (0, -1)
    if len(a) < len(b) and a in b:
        return 2, b.index(a)
    return 0, -1


def _attested(ch: str, by_char: Dict[str, List[str]], counts: "Counter",
              exclude: str, min_attest: int) -> bool:
    """Whether `ch` is used by some *other* reading that itself recurs.

    This is the guard that keeps the consolidation off real course names. 地 is
    attested by 地理, so a grid containing 生地 beside 地理 is never rewritten;
    休 appears in nothing but 休检, so 休检 is. The threshold is what makes it a
    judgement rather than a coincidence — with `min_attest=1` a single stray
    fragment would protect a whole misread family (measured: 生地 is present in
    the sample's cropped variant only twice, and an unguarded rule renamed 20
    cells of 地理 there).
    """
    return any(other != exclude and counts[other] >= min_attest
               for other in by_char.get(ch, ()))


def vocabulary_consolidation(
    readings: Sequence[Sequence[str]],
    *,
    min_target: int = VOCAB_MIN_TARGET,
    min_ratio: float = VOCAB_MIN_RATIO,
    min_backing_ratio: float = VOCAB_MIN_BACKING_RATIO,
    min_attest: int = VOCAB_MIN_ATTEST,
    max_source: int = VOCAB_MAX_SOURCE,
    rounds: int = VOCAB_ROUNDS,
) -> Dict[str, str]:
    """Map rare misreadings onto the frequent names the grid actually uses.

    A timetable repeats the same dozen course names over hundreds of cells, so
    its own vocabulary is evidence about a single cell: a reading seen once next
    to one seen ninety times is a near-miss, and the near-miss is always one
    character off the frequent one.

    `readings` is one entry per *non-empty* cell; the first element is the text
    the grid holds for that cell (its cross-variant vote) and the rest are the
    cell's own variant readings. The frequencies are the grid's votes — the
    offline sweeps that picked every threshold below measured exactly that, and
    counting a single binarisation's opinion instead inverts the rule on rotated
    photos (grey misreads 体检 as 休检 often enough to out-vote the truth).

    Two gates, because the failure modes are opposite. The ballot gate cannot
    invent a correction (the recogniser must have produced the replacement from
    those pixels), but it cannot see a misread all three variants agreed on. The
    attestation gate reaches those, and its guard is what stops it renaming a
    legitimate rare course — which is not hypothetical: an early version without
    the guard renamed 地理 to 物理 on the cropped variant, where 生地 is scarce.

    Rewrites are iterated to a fixed point: folding 苗语→英语 raises 英语's count,
    which is what lets 范语→英语 clear the ratio bar on a later round. The
    attestation evidence is taken from the **raw** votes and held fixed, since
    the first rewrite would otherwise destroy the very evidence protecting a
    legitimate name.
    """
    cell_texts = [entry[0] for entry in readings if entry]
    if not cell_texts:
        return {}

    counts: Counter = Counter(cell_texts)
    by_char: Dict[str, List[str]] = defaultdict(list)
    for text in counts:
        for ch in set(text):
            by_char[ch].append(text)

    backed: Dict[str, set] = defaultdict(set)
    for entry in readings:
        current = entry[0]
        for other in entry[1:]:
            if other != current and _one_char_apart(current, other)[0]:
                if counts[other] >= counts[current] * min_backing_ratio:
                    backed[current].add(other)

    backed: Dict[str, set] = defaultdict(set)
    for readings_for_cell in readings:
        for current in readings_for_cell:
            for other in readings_for_cell:
                if other != current and _one_char_apart(current, other)[0]:
                    if counts[other] >= counts[current] * min_backing_ratio:
                        backed[current].add(other)

    live = dict(counts)
    mapping: Dict[str, str] = {}
    for _round in range(rounds):
        changed = False
        # Ascending source count: the least frequent reading in a confusion
        # family is the most likely misread, so it claims the correction first.
        for text, count in sorted(live.items(), key=lambda kv: kv[1]):
            if text in mapping:
                continue
            options: List[Tuple[float, str]] = []
            for target, target_count in live.items():
                if target == text or target in mapping or target_count < min_target:
                    continue
                kind, pos = _one_char_apart(text, target)
                if not kind:
                    continue
                if target in backed.get(text, ()):
                    # This cell's own pixels say so: local evidence, and the one
                    # route allowed to reach a reading that recurs often (a
                    # systematic misread can repeat ten times in one image).
                    if target_count < count * min_backing_ratio:
                        continue
                elif count > max_source:
                    # Without local evidence, only a rare reading may be
                    # rewritten — a course name that recurs across a grade is
                    # real, however much more frequent its neighbour is.
                    continue
                elif kind == 1 and target_count >= count * min_ratio \
                        and not _attested(text[pos], by_char, counts, text, min_attest):
                    pass
                else:
                    continue
                options.append((1 if target in backed.get(text, ()) else 0,
                                float(target_count), target))
            if not options:
                continue
            # A target the cell's *own pixels* produced (ballot-backed) is stronger
            # evidence than one that merely recurs more often across the grid.
            # Measured on the phone variant: 他理 had two candidates, 地理 (backed by
            # this cell's readings, 15 occurrences) and 物理 (not backed, 75), and
            # sorting on frequency alone turned a vote-stage misread into a
            # *different* wrong answer.
            options.sort(reverse=True)
            # Two equally frequent candidates mean there is no basis to choose:
            # rewriting anyway would be a coin flip, so the reading stands.
            if len(options) > 1 and options[1][:2] == options[0][:2]:
                continue
            mapping[text] = options[0][2]
            changed = True
        if not changed:
            break
        # Fold the round's rewrites in so the next one sees the new frequencies.
        folded: Counter = Counter()
        for text, n in live.items():
            folded[mapping.get(text, text)] += n
        live = dict(folded)

    for key in list(mapping):        # resolve chains (a -> b -> c)
        seen = {key}
        target = mapping[key]
        while target in mapping and target not in seen:
            seen.add(target)
            target = mapping[target]
        mapping[key] = target
    return {k: v for k, v in mapping.items() if k != v}


# ---------------------------------------------------------------------------
# Per-table recognition
# ---------------------------------------------------------------------------


class TableResult:
    """Recognised content of a single table."""

    def __init__(self, columns: List[int], header: List[int], rows: List[Tuple[int, int]]):
        self.columns = columns
        self.header = header
        self.rows = rows
        self.period_columns: List[int] = []
        self.period_numbers: List[int] = []
        self.class_numbers: List[int] = []
        self.class_ok: List[bool] = []
        self.blocks: List[Tuple[int, int, str]] = []
        self.cells: Dict[Tuple[int, int], str] = {}
        self.confidence: Dict[Tuple[int, int], float] = {}
        self.merged: List[dict] = []
        # Every reading taken per cell across `CROP_MODES`, kept so that the
        # vocabulary consolidation can ask whether a candidate correction was
        # actually produced from this cell's own pixels. Bounded by the cell
        # count × variants (≈1600 entries on a full grade sheet), so it costs
        # nothing measurable next to the OCR that produced it.
        self.readings: Dict[Tuple[int, int], List[Tuple[str, float]]] = {}


# Signals that make a header label worth trusting as-is. A label carrying none
# of these is usually blur-garbled, and the cross-variant vote does better.
_HEADER_SIGNALS = ("星期", "节", "课", "班", "级")


def _merge_header_bands(header: Sequence[int], min_height: float = 10.0) -> List[int]:
    """Merge header bands too thin to be a real header row.

    A spurious boundary inside a stacked-glyph header row (a text edge that
    slipped past the rule detector) slices 星期 into a 7px sliver and its
    remainder; each sliver reads as garbage and the label is lost. The sliver's
    bottom boundary is dropped so it fuses with the band below, restoring the
    original row.
    """
    if len(header) < 2:
        return list(header)
    out = [header[0]]
    for y in header[1:]:
        if len(out) >= 2 and y - out[-1] < min_height:
            continue  # sliver: drop this boundary, the open band absorbs it
        out.append(y)
    return out


def read_header_labels(
    engine: OcrEngine, img: np.ndarray, columns: Sequence[int], header: Sequence[int]
) -> List[str]:
    """OCR every header cell and join the bands.

    A header cell can hold stacked text (星期 is drawn as 星 over 期), so each
    header band is read separately and the results concatenated.

    The plain greyscale read is kept whenever it carries a structural signal;
    only a signal-free (typically blur-garbled) label is replaced by the
    cross-variant vote, whose extra binarisations recover glyphs that a single
    resampling pass smeared. Voting unconditionally could let two bad variants
    outvote the one good greyscale read on clean scans.
    """
    n_cols = len(columns) - 1
    labels = [""] * n_cols
    if len(header) < 2:
        return labels
    bands = _merge_header_bands(header)
    for k in range(len(bands) - 1):
        y1, y2 = bands[k], bands[k + 1]
        per_mode = {mode: engine.recognize(
            [prepare_crop(img, y1, y2, columns[i], columns[i + 1], mode=mode)
             for i in range(n_cols)])
            for mode in CROP_MODES}
        for i in range(n_cols):
            grey_text = clean_text(per_mode["gray"][i][0])
            if any(sig in grey_text for sig in _HEADER_SIGNALS):
                labels[i] += grey_text
                continue
            voted, _ = vote_readings([per_mode[m][i] for m in CROP_MODES])
            labels[i] += voted or grey_text
    return labels


def _is_weekday_header(label: str) -> bool:
    """Whether a header label marks a 星期 column.

    On photos the second glyph survives poorly (星期 reads as 星明 / 星) and an
    exact-substring match silently loses half the tables, so a lone 星 counts
    too — as a fallback only, after every exact match had its chance.
    """
    return "星期" in label or "星" in label


def _weekday_table_starts(labels: Sequence[int], min_span: int = 3) -> List[int]:
    """Column indices where a new table starts (each 星期 column starts one).

    Exact 星期 matches are trusted outright; lone 星 matches are accepted only
    when no exact match sits within `min_span` columns, so a garbled 班 header
    next to a real 星期 column cannot spawn a phantom one-column table.
    """
    starts = [i for i, label in enumerate(labels) if "星期" in label]
    for i, label in enumerate(labels):
        if "星" in label and i not in starts:
            if all(abs(i - s) >= min_span for s in starts):
                starts.append(i)
    return sorted(starts)


def classify_columns(
    labels: Sequence[str],
) -> Tuple[List[int], List[int], Optional[int], Optional[int]]:
    """Return (period column indices, period numbers, 班 column, 星期 column).

    The 班 column is located positionally — it is the column right after 星期 —
    because its single complex glyph is unreliable to recognise, while the
    layout is not. The header text is used only as a confirmation.
    """
    period_columns: List[int] = []
    period_numbers: List[int] = []
    weekday_col: Optional[int] = None
    labelled_class_col: Optional[int] = None

    for idx, label in enumerate(labels):
        match = re.search(r"第\s*(\d+)\s*[节課课]", label)
        if match:
            period_columns.append(idx)
            period_numbers.append(int(match.group(1)))
            continue
        if weekday_col is None and _is_weekday_header(label):
            weekday_col = idx
            continue
        if labelled_class_col is None and ("班" in label or "级" in label):
            labelled_class_col = idx

    if weekday_col is not None:
        candidate = weekday_col + 1
        if candidate < len(labels) and candidate not in period_columns:
            class_col = candidate
        else:
            class_col = labelled_class_col
    else:
        class_col = labelled_class_col
    return period_columns, period_numbers, class_col, weekday_col


def read_class_column(
    engine: OcrEngine, img: np.ndarray, columns: Sequence[int],
    rows: Sequence[Tuple[int, int]], col_idx: Optional[int],
) -> Tuple[List[int], List[bool]]:
    """OCR the 班 column.

    Returns (numbers, oks): `numbers` falls back to the 1-based row index where
    nothing was read, and `oks` records which entries are real digit reads —
    the fallback values are row indices, poison for any structure analysis.
    """
    n = len(rows)
    if col_idx is None:
        return list(range(1, n + 1)), [False] * n
    x1, x2 = columns[col_idx], columns[col_idx + 1]
    crops = [prepare_crop(img, y1, y2, x1, x2) for y1, y2 in rows]
    numbers: List[int] = []
    oks: List[bool] = []
    for i, (text, _) in enumerate(engine.recognize(crops)):
        match = re.search(r"\d+", clean_text(text))
        if match:
            numbers.append(int(match.group()))
            oks.append(True)
        else:
            numbers.append(i + 1)
            oks.append(False)
    return numbers, oks


def _bands_in_column(mask: np.ndarray, x1: int, x2: int,
                     y_top: int, y_bot: int) -> List[Tuple[int, int]]:
    """Contiguous runs of inked rows inside a narrow column strip."""
    strip = mask[y_top:y_bot, max(0, x1 + 2):max(0, x2 - 2)]
    if strip.size == 0:
        return []
    projection = (strip > 0).sum(axis=1)
    bands: List[Tuple[int, int]] = []
    start = None
    for i, value in enumerate(projection):
        if value > 0 and start is None:
            start = i
        elif value == 0 and start is not None:
            bands.append((y_top + start, y_top + i))
            start = None
    if start is not None:
        bands.append((y_top + start, y_top + len(projection)))
    return bands


def _vote_band_reads(
    engine: OcrEngine, img: np.ndarray, bands: Sequence[Tuple[int, int]],
    x1: int, x2: int,
) -> List[Tuple[str, float]]:
    """Read every glyph band under all binarisation variants and vote per band.

    Cells vote across variants (see `vote_readings`); narrow glyph bands — the
    星期 labels and merged-cell captions — benefit just as much on fuzzy or
    shaded photos, and cost little: bands are few and small.
    """
    if not bands:
        return []
    per_mode = {
        mode: engine.recognize(
            # pad_x insets 2px: dotted cell borders survive text_only_mask as
            # fragments inside the strip, and they poison the recogniser (a
            # 0.99-confident 体 reads as nothing until the border is cut off).
            [prepare_band_crop(img, a, b, x1, x2, mode=mode, pad_x=-2)
             for a, b in bands]
        )
        for mode in BAND_MODES
    }
    return [vote_readings([per_mode[m][i] for m in BAND_MODES])
            for i in range(len(bands))]


def _class_restart_starts(numbers: Sequence[int], oks: Sequence[bool],
                          n_rows: int) -> List[int]:
    """Rows where the 班 column restarts at 1 — each one starts a day block.

    Only rows whose digit was actually read count (the fallback value is a row
    index), and a restart is trusted when the following row reads 2 or was
    unread; single stray 1s inside a block are rejected that way.
    """
    starts: List[int] = []
    for i, (num, ok) in enumerate(zip(numbers, oks)):
        if not ok or num != 1:
            continue
        if i > 0 and oks[i - 1] and numbers[i - 1] == 1:
            continue
        if i + 1 >= n_rows or not oks[i + 1] or numbers[i + 1] == 2:
            starts.append(i)
    return starts


def _starts_plausible(starts: Sequence[int], n_rows: int) -> bool:
    """Whether restart-based blocks are near-uniform (grade timetables are).

    The tolerance is deliberately tight. A JPEG-degraded 班 column can lose its
    first two restarts and keep only a later one, giving blocks of 44 and 22
    rows against a true structure of 22/22/22 — a 33% deviation that the old
    35% bound accepted, so a *wrong* split was trusted over the 星期-label
    grouping that would have found all three blocks (measured: the jpeg55
    variant of the sample fixture dropped 星期四 entirely that way).
    """
    if len(starts) < 2:
        return False
    bounds = list(starts) + [n_rows]
    sizes = [b - a for a, b in zip(bounds, bounds[1:])]
    mean = sum(sizes) / len(sizes)
    return mean > 0 and max(abs(s - mean) for s in sizes) <= 0.20 * mean


def detect_day_blocks(
    engine: OcrEngine, img: np.ndarray, mask: np.ndarray,
    columns: Sequence[int], rows: Sequence[Tuple[int, int]],
    class_numbers: Optional[Sequence[int]] = None,
    class_ok: Optional[Sequence[bool]] = None,
) -> List[Tuple[int, int, str]]:
    """Split the data rows into day blocks and read each block's weekday.

    Block structure comes from the strongest available signal: the 班 column
    restarting at 1 (structural, survives anything done to the 星期 glyphs),
    falling back to grouping the 星期 label bands. Either way the weekday is
    then read from the label bands inside each block; labels that still fail
    are recovered by sequence inference in `_infer_missing_days`.

    The label is drawn vertically: 星 and 期, then the day character. Each glyph
    is about one row tall, so the column is projected into glyph bands rather
    than cropped per row (which would slice the characters in half).

    The day character itself is sometimes just stacked horizontal bars (一 / 二 /
    三), which the recogniser cannot read reliably; when a group of thin bars is
    found, the number of bars identifies the character instead.
    """
    n_rows = len(rows)
    if len(columns) < 2 or not rows:
        return [(0, n_rows - 1, "")] if rows else []

    x1, x2 = columns[0], columns[1]
    y_top, y_bot = rows[0][0], rows[-1][1]
    bands = _bands_in_column(mask, x1, x2, y_top, y_bot)
    # The header's own 星期 label can dip below the first data rule on deskewed
    # photos; its tail inside the data region would seed a phantom day block.
    above = mask[max(0, y_top - 24):y_top, max(0, x1 + 2):max(0, x2 - 2)]
    if bands and bands[0][0] - y_top < 4 and (above > 0).sum() > 20:
        bands = bands[1:]
    bands = _merge_close_bands(bands)

    # ── block structure ──────────────────────────────────────
    starts: Optional[List[int]] = None
    if class_numbers and class_ok:
        restarts = _class_restart_starts(class_numbers, class_ok, n_rows)
        # Block one always starts at row 0, digit read or not; without this a
        # spurious restart rows below the top would orphan every row above it.
        if restarts and restarts[0] > 0:
            restarts = [0] + restarts
        if _starts_plausible(restarts, n_rows):
            starts = restarts

    if starts is None:
        starts = _day_blocks_from_label_groups(
            engine, img, bands, rows, x1, x2)

    # ── per-block weekday reading ────────────────────────────
    def row_of(centre: float) -> int:
        idx = next((i for i, (ry1, ry2) in enumerate(rows) if ry1 <= centre < ry2), None)
        if idx is None:
            idx = min(range(n_rows),
                      key=lambda i: abs((rows[i][0] + rows[i][1]) / 2.0 - centre))
        return idx

    bounds = list(starts) + [n_rows]
    blocks: List[Tuple[int, int, str]] = []
    for s, e in zip(bounds, bounds[1:]):
        items: List[Tuple[int, int, int, str, float]] = []
        for a, b in bands:
            centre = (a + b) / 2.0
            r = row_of(centre)
            if s <= r <= e:
                text, score = _vote_band_reads(engine, img, [(a, b)], x1, x2)[0]
                items.append((r, a, b, clean_text(text), score))
        day = _read_day_character(engine, img, items, x1, x2) if items else ""
        blocks.append((s, e - 1, day))
    return _infer_missing_days(blocks)


def _day_blocks_from_label_groups(
    engine: OcrEngine, img: np.ndarray,
    bands: Sequence[Tuple[int, int]],
    rows: Sequence[Tuple[int, int]], x1: int, x2: int,
) -> List[int]:
    """Block starts from grouping the 星期 label bands (no 班 column signal).

    Glyphs of one label sit within a few rows of each other; labels split at
    the midpoint of their glyph centres. Grade timetables give every class the
    same number of rows per day, so when the block count is known the
    boundaries are snapped to an equal division of the rows — this repairs the
    drift that a label read a row or two off centre would otherwise leave in
    every following block.
    """
    if not bands:
        return [0]
    readings = _vote_band_reads(engine, img, bands, x1, x2)
    centres = [(a + b) / 2.0 for a, b in bands]
    items: List[Tuple[int, int, int, str, float]] = []
    for (a, b), centre, (text, score) in zip(bands, centres, readings):
        idx = next((i for i, (ry1, ry2) in enumerate(rows) if ry1 <= centre < ry2), None)
        if idx is None:
            idx = min(range(len(rows)),
                      key=lambda i: abs((rows[i][0] + rows[i][1]) / 2.0 - centre))
        items.append((idx, a, b, clean_text(text), score))

    groups: List[List[Tuple[int, int, int, str, float]]] = [[items[0]]]
    for item in items[1:]:
        if item[0] - groups[-1][-1][0] <= 4:
            groups[-1].append(item)
        else:
            groups.append([item])
    if len(groups) < 2:
        return [0]

    group_centres = [sum(it[0] for it in g) / float(len(g)) for g in groups]
    boundaries = [int(round((group_centres[i - 1] + group_centres[i]) / 2.0))
                  for i in range(1, len(groups))]

    num_blocks = len(groups)
    if num_blocks >= 2:
        size = len(rows) / num_blocks
        if abs(size - round(size)) < 0.35:
            size = int(round(size))
            starts_c = [0] + boundaries
            ends_c = boundaries + [len(rows)]
            if all(abs((e - s) - size) <= 3 for s, e in zip(starts_c, ends_c)):
                boundaries = [k * size for k in range(1, num_blocks)]
    return [0] + boundaries


def _merge_close_bands(bands: Sequence[Tuple[int, int]],
                       gap: int = 2) -> List[Tuple[int, int]]:
    """Fuse bands separated by ≤`gap` rows of blank — fragments of one glyph."""
    if not bands:
        return []
    out: List[List[int]] = [[bands[0][0], bands[0][1]]]
    for a, b in bands[1:]:
        if a - out[-1][1] <= gap:
            out[-1][1] = max(out[-1][1], b)
        else:
            out.append([a, b])
    return [(a, b) for a, b in out]


def _is_stacked_bars(day_items: Sequence[Tuple[int, int, int, str, float]]) -> bool:
    """Whether the day glyph is 一 / 二 / 三 (stacked thin bars).

    The recogniser cannot read these reliably — it tends to return fewer bars
    than there are (二 as 一) — so they are identified structurally instead.
    The key point is that the bars are *separated*: 日 is a box whose vertical
    strokes connect its three horizontal strokes, so its row projection has no
    blank row at all and reads as one tall band. Separation is measured in
    pixels between consecutive bands.
    """
    if not 1 <= len(day_items) <= 3:
        return False
    if max(it[2] - it[1] for it in day_items) > 3:
        return False  # a tall band is a connected glyph (e.g. 日), not a thin bar
    return all(
        day_items[i + 1][1] - day_items[i][2] >= 1
        for i in range(len(day_items) - 1)
    )


def _read_day_character(
    engine: OcrEngine, img: np.ndarray,
    group: Sequence[Tuple[int, int, int, str, float]], x1: int, x2: int,
) -> str:
    """Identify the weekday character of one 星期 label group.

    Sources are tried in order of reliability:

    1. the per-glyph readings — but never 日, which is ambiguous with 三 and is
       better settled by the whole-glyph read below;
    2. the bar count, when the glyph really is stacked thin bars (一 / 二 / 三);
    3. the whole day glyph read as one crop — the only source trusted for 日,
       i.e. for 星期日.
    """
    # 星 and 期 are the same for every block; the day character is what remains.
    day_items = [it for it in group if not any(c in it[3] for c in "星期")]
    if not day_items:
        day_items = list(group[-1:])
    if not day_items:
        return ""

    # 一 / 二 / 三 are stacked thin bars, and every recogniser tends to read n
    # bars as fewer (二 as 一, 三 as 二) — the bar count is structural evidence
    # and outranks any OCR reading of these glyphs.
    if _is_stacked_bars(day_items):
        return "星期" + "一二三"[len(day_items) - 1]

    for item in reversed(day_items):
        if item[4] < DAY_MIN_CONFIDENCE:
            continue
        for ch in item[3]:
            # 日 is deliberately excluded: it is indistinguishable from 三 here
            if ch in DAY_CHARS and ch != "日":
                return "星期" + ch

    top = min(it[1] for it in day_items)
    bottom = max(it[2] for it in day_items)
    height = bottom - top

    # The day character is the bottom glyph of the vertically stacked label.
    # On noisy or blurred photos the per-glyph band reads fragment it, but the
    # bottom third of the whole label is still a clean single-glyph crop.
    if height > 24:
        crop_top = bottom - max(14, height // 3)
        readings = engine.recognize([
            prepare_band_crop(img, crop_top, bottom, x1, x2, pad_y=4, pad_x=-2, mode=mode)
            for mode in BAND_MODES
        ])
        text, score = vote_readings(readings)
        if score >= DAY_MIN_CONFIDENCE:
            for ch in clean_text(text):
                if ch in DAY_CHARS:
                    return "星期" + ch

    readings = engine.recognize([
        prepare_band_crop(img, top, bottom, x1, x2, pad_y=5, pad_x=-2, mode=mode)
        for mode in BAND_MODES
    ])
    text, score = vote_readings(readings)
    if score >= DAY_MIN_CONFIDENCE:
        for ch in clean_text(text):
            if ch in DAY_CHARS:
                return "星期" + ch
    return ""


def _infer_missing_days(
    blocks: Sequence[Tuple[int, int, str]],
    groups: Optional[Sequence[int]] = None,
) -> List[Tuple[int, int, str]]:
    """Fill unreadable day labels from neighbouring blocks.

    Day blocks run in weekday order, so a label that could not be recognised can
    be recovered from an adjacent one. Blocks that still cannot be resolved are
    left blank and simply contribute no columns.

    A repeated label is treated as unread, not as a reading. Within one table two
    blocks are physically different weekdays, so the second 星期一 in a sequence
    is a misread (measured: a 2.5° tilt made 星期三 read as 星期一 at high
    confidence, which is a *wrong* value, not a missing one, and it pushed the
    table's third block onto Monday). Non-increasing labels are the same signal
    and are handled the same way.

    `groups` gives how many consecutive blocks belong to each table, in order.
    It matters because the sequence only restarts *between* tables: a layout with
    two side-by-side tables that each hold a full week has two 星期一 in the flat
    list, and treating the second as a misread blanks 星期一..星期五 and relabels
    them 星期六/星期日/blank/blank/blank while the real 星期六/星期日 belong to
    neither (measured against exactly that layout). So the duplicate pass runs per
    table, and only a repeat inside one table counts as a misread.

    Blanks are filled by interpolating *between* the two known labels that bound
    them, and only when the gap fits exactly: a run of n blank blocks between day
    a and day b is 星期a+1..a+n iff b - a == n + 1. Otherwise the run is left
    blank rather than invented, because an inexact gap means the table is not what
    this simple sequence assumes. Filling each blank from its predecessor
    independently, as an earlier version did, created duplicate weekdays:
    a table reading 星期一 / (blank) / 星期二 has its middle block filled as
    星期二, colliding with the real 星期二 and merging two day blocks into one
    column (measured — a 3-block table with the middle label unreadable is exactly
    that input). One-sided runs (at the table's start or end) extend from the side
    that exists, which cannot collide because the run is maximal.
    """
    index_of = {ch: i for i, ch in enumerate(DAY_CHARS)}
    result = list(blocks)
    bounds: List[Tuple[int, int]] = []
    if groups:
        cursor = 0
        for count in groups:
            bounds.append((cursor, cursor + count))
            cursor += count
        if cursor < len(result):
            bounds.append((cursor, len(result)))
    else:
        bounds = [(0, len(result))] if result else []

    def day_index(label: str) -> Optional[int]:
        if label.startswith("星期") and len(label) == 3 and label[2] in index_of:
            return index_of[label[2]]
        return None

    def label(index: int) -> str:
        return "星期" + DAY_CHARS[index]

    def fill_span(start: int, end: int) -> None:
        """Fill result[start:end] (all blank) from the known labels around it."""
        if start >= end:
            return
        prev_idx = day_index(result[start - 1][2]) if start > 0 else None
        next_idx = day_index(result[end][2]) if end < len(result) else None
        span = end - start
        if prev_idx is not None and next_idx is not None:
            if next_idx - prev_idx == span + 1:
                for k in range(span):
                    result[start + k] = (result[start + k][0], result[start + k][1],
                                         label(prev_idx + 1 + k))
            # An inexact gap means blocks are missing, not just labels: leaving
            # the run blank is the only honest reading.
            return
        if prev_idx is not None:
            for k in range(span):
                idx = prev_idx + 1 + k
                if idx >= len(DAY_CHARS):
                    break
                result[start + k] = (result[start + k][0], result[start + k][1], label(idx))
            return
        if next_idx is not None:
            for k in range(span):
                idx = next_idx - (span - k)
                if idx < 0:
                    continue
                result[start + k] = (result[start + k][0], result[start + k][1], label(idx))

    def within(start: int, end: int) -> None:
        last_known = -1
        for i in range(start, end):
            idx = day_index(result[i][2])
            if idx is not None and idx <= last_known:
                result[i] = (result[i][0], result[i][1], "")
                continue
            if idx is not None:
                last_known = idx
        # Fill each run of blanks as a unit, so a run can be interpolated between
        # its neighbours instead of guessed from one side.
        i = start
        while i < end:
            if day_index(result[i][2]) is None:
                j = i
                while j < end and day_index(result[j][2]) is None:
                    j += 1
                fill_span(i, j)
                i = j
            else:
                i += 1

    for start, end in bounds:
        within(start, end)

    # A table whose own labels *all* failed takes its weekdays from the table
    # beside it, because side-by-side tables hold consecutive day ranges. The
    # condition is the point: a blank *inside* a table whose other labels were
    # read is not the same situation, and filling it from the previous table's
    # last day invents a weekday that collides with the table's own — measured on
    # a two-table layout, the right table's unreadable 星期一 became 星期六
    # (the left table's 星期五 plus one) while the right table's real 星期二..五
    # were still there. Only a group with no surviving label is continued across
    # the boundary, and `fill_span` still refuses to invent anything when the gap
    # does not fit the sequence.
    for start, end in bounds:
        if any(day_index(result[i][2]) is not None for i in range(start, end)):
            continue
        fill_span(start, end)
    return result


def _is_separator_glyph(mask: np.ndarray, band: Tuple[int, int],
                        x1: int, x2: int) -> bool:
    """Whether a glyph band is a vertical separator stroke (the / of 体锻/劳动).

    Written down a 15px column, a slash is 1-2px of ink per row drifting steadily
    sideways; every recogniser reads it as 1, or as a letter, or as nothing —
    and the pipeline then drops it, turning 体锻/劳动 into 体锻劳动. The geometry is
    the only reliable evidence, and it is unambiguous: across all eight accuracy
    variants the five separators each read at most 2px in their densest row with
    a monotone 4-5px centre drift, while no other glyph band in a merged cell
    comes close (体 has 8px in its densest row, 动 7px, and both are non-monotone).
    """
    y1, y2 = band
    height = y2 - y1
    if not SEPARATOR_MIN_HEIGHT <= height <= SEPARATOR_MAX_HEIGHT:
        return False
    strip = mask[y1:y2, max(0, x1 + 2):max(0, x2 - 2)]
    if strip.size == 0:
        return False
    rows = [np.flatnonzero(row) for row in (strip > 0)]
    ink = [len(r) for r in rows]
    if not ink or max(ink) > SEPARATOR_MAX_ROW_INK:
        return False
    centres = [float(r.mean()) for r in rows if len(r)]
    if len(centres) < height * 0.6:
        return False        # a real glyph inks most of its own band
    if abs(centres[-1] - centres[0]) < SEPARATOR_MIN_DRIFT:
        return False
    return (all(centres[i + 1] <= centres[i] for i in range(len(centres) - 1))
            or all(centres[i + 1] >= centres[i] for i in range(len(centres) - 1)))


def _is_cjk(text: str) -> bool:
    return any("\u4e00" <= ch <= "\u9fff" for ch in text)


def detect_merged_cells(
    engine: OcrEngine, img: np.ndarray, mask: np.ndarray,
    columns: Sequence[int], rows: Sequence[Tuple[int, int]], period_cols: Sequence[int],
    blocks: Sequence[Tuple[int, int, str]],
) -> List[dict]:
    """Find cells whose text spans several rows (e.g. 班会 written over 5 rows).

    A merged region looks like a mostly-empty column holding a few single glyphs
    stacked down it. The glyphs are found by projecting the column, exactly as
    for the 星期 labels, and joined in reading order. Requiring every band to be
    a single character is what separates a merged label from an ordinary column
    that happens to be sparsely filled.

    The scan is per day block: a column is normally full in one block and may
    hold a merged label in another, so pooling the whole table would hide it.
    """
    merged: List[dict] = []
    if not rows:
        return merged

    for block_start, block_end, _day in blocks:
        block_rows = list(rows[block_start:block_end + 1])
        if not block_rows:
            continue
        y_top, y_bot = block_rows[0][0], block_rows[-1][1]

        for pc in period_cols:
            x1, x2 = columns[pc], columns[pc + 1]
            densities = [ink_ratio(mask, y1, y2, x1, x2) for y1, y2 in block_rows]
            if not densities or float(np.median(densities)) >= MERGED_EMPTY_MEDIAN:
                continue  # a normally-filled column, not a merged region

            bands = _bands_in_column(mask, x1, x2, y_top, y_bot)
            # A glyph split across two fragments (a 2px gap inside 会) reads as
            # nothing on either fragment; fused, it reads as the glyph again.
            bands = _merge_close_bands(bands)
            if not 1 <= len(bands) <= MERGED_MAX_GLYPHS:
                continue

            chars: List[str] = []
            for band, (text, score) in zip(bands, _vote_band_reads(engine, img, bands, x1, x2)):
                if _is_separator_glyph(mask, band, x1, x2):
                    # The separator is real content even though it is not a
                    # character: keeping it is what makes 体锻/劳动 read as written
                    # rather than as 体锻劳动. Attested structurally, so it is
                    # recorded here rather than alongside the OCR readings.
                    chars.append("/")
                    continue
                value = clean_text(text)
                if not value or score < MERGED_MIN_CONFIDENCE:
                    chars.append("")
                    continue
                # A glyph split across two bands reads as the same character
                # twice (会 over two bands), so collapse the repeat.
                if chars and chars[-1] == value:
                    chars.append("")
                    continue
                chars.append(value)
            # A lone digit flanked by CJK glyphs is a misread separator the
            # geometry above did not catch (a slanted 1 is a slash with a flag):
            # 体锻/劳动 → 体锻1劳动. Dropping it keeps the text clean, and when the
            # geometry *did* identify the glyph the "/" above is already there.
            for i in range(1, len(chars) - 1):
                if chars[i].isdigit() and len(chars[i]) == 1 \
                        and chars[i - 1] and chars[i + 1] \
                        and _is_cjk(chars[i - 1]) and _is_cjk(chars[i + 1]):
                    chars[i] = ""
            text = "".join(chars)
            # 单字合并格（例如只写了一个“会”）也是有效内容，不能丢
            if len(text) < 1:
                continue

            start = block_start + _row_at(block_rows, bands[0][0])
            end = block_start + _row_at(block_rows, bands[-1][1] - 1)
            if end < start:
                start, end = end, start
            merged.append({
                "column_index": pc,
                "row_start": start,
                "row_end": end,
                "text": text,
                "chars": chars,
            })
    return merged


def _row_at(rows: Sequence[Tuple[int, int]], y: int) -> int:
    """Index of the row containing y (nearest row when y falls between rows)."""
    for i, (y1, y2) in enumerate(rows):
        if y1 <= y < y2:
            return i
    return min(range(len(rows)), key=lambda i: abs(rows[i][0] - y))


def vote_readings(readings: Sequence[Tuple[str, float]]) -> Tuple[str, float]:
    """Combine one cell's readings across binarisation variants.

    A clear majority wins; on a tie the most confident reading is used, and if
    all variants disagree the single most confident one is taken.
    """
    cleaned: List[Tuple[str, float]] = []
    for text, score in readings:
        value = clean_text(text)
        if value and score >= MIN_VOTE_CONFIDENCE:
            cleaned.append((value, score))
    if not cleaned:
        return "", 0.0
    counts = Counter(text for text, _ in cleaned)
    best_count = counts.most_common(1)[0][1]
    winners = [text for text, n in counts.items() if n == best_count]
    if len(winners) == 1:
        chosen = winners[0]
    else:
        chosen = max(winners, key=lambda t: max(s for text, s in cleaned if text == t))
    return chosen, max(s for text, s in cleaned if text == chosen)


def recognize_table(
    engine: OcrEngine, img: np.ndarray, mask: np.ndarray,
    columns: List[int], header: List[int], rows: List[Tuple[int, int]],
) -> TableResult:
    """Full recognition pass over one table."""
    table = TableResult(columns, header, rows)
    if not rows:
        return table

    labels = read_header_labels(engine, img, columns, header)
    period_cols, period_numbers, class_col, _weekday_col = classify_columns(labels)
    if not period_cols:
        period_cols = list(range(2, len(columns) - 1))
        period_numbers = list(range(1, len(period_cols) + 1))
    table.period_columns = period_cols
    table.period_numbers = period_numbers

    numbers, oks = read_class_column(engine, img, columns, rows, class_col)
    if not _starts_plausible(
            _class_restart_starts(numbers, oks, len(rows)), len(rows)):
        # No usable 班 column signal where the header pointed. When the header
        # labels are gone entirely (cropped, blurred), the 班 column sits right
        # after the 星期 column — or IS the first column when that one was the
        # casualty. Probe the usual suspects for a 1,2,3… restart pattern.
        for cand in (1, 0, 2):
            if cand >= len(columns) - 1 or cand == class_col:
                continue
            cand_numbers, cand_oks = read_class_column(
                engine, img, columns, rows, cand)
            if _starts_plausible(
                    _class_restart_starts(cand_numbers, cand_oks, len(rows)),
                    len(rows)):
                class_col = cand
                numbers, oks = cand_numbers, cand_oks
                break
    table.class_numbers, table.class_ok = numbers, oks
    table.blocks = detect_day_blocks(engine, img, mask, columns, rows,
                                     table.class_numbers, table.class_ok)

    # --- batched recognition of every period cell, one pass per variant ---
    keys: List[Tuple[int, int]] = []
    per_mode_crops: Dict[str, List[np.ndarray]] = {mode: [] for mode in CROP_MODES}
    for r, (y1, y2) in enumerate(rows):
        for pc in period_cols:
            keys.append((r, pc))
            for mode in CROP_MODES:
                per_mode_crops[mode].append(prepare_crop(img, y1, y2, columns[pc], columns[pc + 1], mode))

    per_mode_results: Dict[str, List[Tuple[str, float]]] = {
        mode: engine.recognize(per_mode_crops[mode]) for mode in CROP_MODES
    }

    for i, key in enumerate(keys):
        readings = [per_mode_results[mode][i] for mode in CROP_MODES]
        r, pc = key
        # Raw, uncleaned readings: the consolidation gate compares a correction
        # against what the recogniser actually produced, and cleaning twice
        # (before and after the empty-cell check) would let a reading that only
        # survives as punctuation back a rewrite.
        table.readings[(r, pc)] = list(readings)
        text, score = vote_readings(readings)
        if not text:
            continue
        # A cell with no text ink at all is empty, whatever the recogniser
        # hallucinated on its blank crop (a lone 1 at low confidence).
        y1, y2 = rows[r]
        if ink_ratio(mask, y1, y2, columns[pc], columns[pc + 1]) < EMPTY_CELL_INK:
            continue
        table.cells[key] = text
        table.confidence[key] = score

    # --- merged (vertically spanning) cells -------------------------------
    table.merged = detect_merged_cells(engine, img, mask, columns, rows,
                                       period_cols, table.blocks)
    for item in table.merged:
        for r in range(item["row_start"], item["row_end"] + 1):
            table.cells.pop((r, item["column_index"]), None)
            # The confidence goes with the cell. Leaving it behind makes the
            # reported mean and low-confidence counts describe a different set of
            # readings than `nonEmpty` does (measured on a week6 variant: 4
            # confidences against 1 surviving cell), and the mean-then feeds the
            # unresolved decision.
            table.confidence.pop((r, item["column_index"]), None)

    return table


# ---------------------------------------------------------------------------
# Grid assembly and CSV projection
# ---------------------------------------------------------------------------


def _block_class_numbers(observed: Sequence[int],
                         oks: Optional[Sequence[bool]] = None) -> List[int]:
    """Class numbers for one day block.

    The 班 column simply numbers the rows 1..N inside each block, so a clean
    consecutive run of real digit reads is trusted as-is (it may well start
    above 1 — the top rows of the grade can be cropped away). A block whose
    digits were all unreadable falls back to the 1-based row index, which only
    equals the class numbering when the block starts at the first row.
    """
    values = list(observed)
    real = [bool(ok) for ok in (oks if oks is not None else [])]
    if not values:
        return []
    if not any(real):
        return list(range(1, len(values) + 1))
    if all(isinstance(v, int) and v > 0 for v in values) and \
            all(values[i + 1] - values[i] == 1 for i in range(len(values) - 1)):
        return values
    return list(range(1, len(values) + 1))


def assemble_grid(tables: Sequence[TableResult]) -> dict:
    """Merge per-table results into one (day x class x period) structure.

    When not a single day label survived OCR, the blocks are renumbered by
    layout order instead of dropping the whole run: school timetables run
    Monday onward, tables left to right, blocks top to bottom. The caller
    surfaces this as a warning via the `days_inferred` flag.
    """
    grid: Dict[str, Dict[str, Dict[str, str]]] = defaultdict(lambda: defaultdict(dict))
    all_classes: set = set()
    days: List[str] = []
    days_inferred = False

    counts = [len(t.blocks) for t in tables]
    flat = [b for t in tables for b in t.blocks]
    # Day inference runs across tables: with two tables side by side the left
    # one's labels may all fail while the right one's survive, and the sequence
    # anchor is global (tables hold consecutive day ranges). The *duplicate*
    # filtering is per table though — two tables that each hold a full week
    # legitimately contain two 星期一, and only a repeat inside one table is a
    # misread. See `_infer_missing_days` for the measurement.
    flat = _infer_missing_days(flat, counts)
    if flat and not any(day for _, _, day in flat):
        days_inferred = True
        flat = [
            (start, end, "星期" + DAY_CHARS[i] if i < len(DAY_CHARS) else "")
            for i, (start, end, _) in enumerate(flat)
        ]
        block_lists: List[List[Tuple[int, int, str]]] = []
        cursor = 0
        for n in counts:
            block_lists.append(flat[cursor:cursor + n])
            cursor += n
    else:
        block_lists = []
        cursor = 0
        for n in counts:
            block_lists.append(flat[cursor:cursor + n])
            cursor += n

    for table, blocks in zip(tables, block_lists):
        merged_by_col: Dict[int, List[dict]] = defaultdict(list)
        for item in table.merged:
            merged_by_col[item["column_index"]].append(item)

        for start, end, day in blocks:
            if not day:
                continue
            if day not in days:
                days.append(day)
            observed = table.class_numbers[start:end + 1]
            observed_ok = table.class_ok[start:end + 1] \
                if len(table.class_ok) == len(table.class_numbers) else None
            class_numbers = _block_class_numbers(observed, observed_ok)
            for offset, r in enumerate(range(start, end + 1)):
                class_no = class_numbers[offset]
                all_classes.add(class_no)
                for pc, period in zip(table.period_columns, table.period_numbers):
                    text = table.cells.get((r, pc), "")
                    if text:
                        grid[day][str(class_no)][str(period)] = text
                for pc, items in merged_by_col.items():
                    if pc not in table.period_columns:
                        continue
                    period = table.period_numbers[table.period_columns.index(pc)]
                    for item in items:
                        if item["row_start"] <= r <= item["row_end"]:
                            grid[day][str(class_no)][str(period)] = item["text"]

    ordered_days = [d for d in WEEKDAYS if d in days] + [d for d in days if d not in WEEKDAYS]
    return {
        "days": ordered_days,
        "classes": sorted(all_classes),
        "grid": {d: {c: dict(v) for c, v in classes.items()} for d, classes in grid.items()},
        "days_inferred": days_inferred,
    }


def _grid_slots(tables: Sequence[TableResult]) -> Dict[Tuple[str, str, str], Tuple[int, int, int]]:
    """Map each grid cell back to (table index, row, period column) for readings.

    The walk mirrors `assemble_grid`: class numbers are renumbered per day block
    (`_block_class_numbers`), so the absolute row index and the class number the
    grid holds diverge wherever the 班 column's digits did not read as a clean
    run. The table index has to travel with the cell — two tables side by side
    both number their rows from 0, so a bare (row, column) pair would fetch the
    left table's readings for a right-table cell. Cells written by the
    merged-cell pass are omitted: their text was read per glyph band from a
    column projection, not per cell, so there is no per-cell reading to back a
    correction anyway.
    """
    slots: Dict[Tuple[str, str, str], Tuple[int, int, int]] = {}
    for index, table in enumerate(tables):
        merged_by_col: Dict[int, List[dict]] = defaultdict(list)
        for item in table.merged:
            merged_by_col[item["column_index"]].append(item)
        period_of = {pc: per for pc, per in zip(table.period_columns, table.period_numbers)}
        for start, end, day in table.blocks:
            if not day:
                continue
            observed = table.class_numbers[start:end + 1]
            observed_ok = table.class_ok[start:end + 1] \
                if len(table.class_ok) == len(table.class_numbers) else None
            class_numbers = _block_class_numbers(observed, observed_ok)
            for offset, row in enumerate(range(start, end + 1)):
                if offset >= len(class_numbers):
                    continue
                cls = str(class_numbers[offset])
                for pc, period in period_of.items():
                    slots[(day, cls, str(period))] = (index, row, pc)
                for pc, items in merged_by_col.items():
                    if pc not in period_of:
                        continue
                    period = str(period_of[pc])
                    for item in items:
                        if item["row_start"] <= row <= item["row_end"]:
                            slots.pop((day, cls, period), None)
    return slots


def consolidate_grid(assembled: dict, tables: Sequence[TableResult]) -> List[Tuple[str, str, int]]:
    """Apply the vocabulary consolidation to a grid in place.

    Returns the rewrites that were made, as (from, to, cells changed), for the
    caller to report.

    The readings that back a correction come from the table the cell was read
    from, so a rewrite is only made when the recogniser produced the replacement
    from *that cell's* pixels (or the attestation guard clears it — see
    `vocabulary_consolidation`).
    """
    slots = _grid_slots(tables)
    grid = assembled["grid"]

    per_cell: List[List[str]] = []
    for day, classes in grid.items():
        for cls, periods in classes.items():
            for period, text in periods.items():
                if not text:
                    continue
                # The cell's own text leads, its variant readings follow: the
                # frequencies that drive the rule are the grid's votes, not one
                # binarisation's opinion. Using a single variant here instead
                # inverted the rule on rotated photos — grey reads 体检 as 休检
                # often enough that 体检→休检 out-counted the truth and renamed
                # fourteen correct cells (measured, rot-1.5).
                entry = [text]
                slot = slots.get((day, cls, period))
                if slot is not None:
                    entry += [value for value in (clean_text(t) for t, _s in
                                                  _readings_at(tables, slot)) if value]
                per_cell.append(entry)

    mapping = vocabulary_consolidation(per_cell)
    if not mapping:
        return []

    changed: Counter = Counter()
    for classes in grid.values():
        for periods in classes.values():
            for period, text in periods.items():
                replacement = mapping.get(text)
                if replacement and replacement != text:
                    periods[period] = replacement
                    changed[(text, replacement)] += 1
    return [(src, dst, n) for (src, dst), n in sorted(changed.items())]


def _readings_at(tables: Sequence[TableResult],
                 slot: Tuple[int, int, int]) -> List[Tuple[str, float]]:
    """The per-variant readings recorded for one table cell, if any."""
    index, row, pc = slot
    if not 0 <= index < len(tables):
        return []
    return tables[index].readings.get((row, pc)) or []


def project_csv(assembled: dict, class_no: int) -> Tuple[List[List[str]], List[str]]:
    """Project the grid onto (period x day) rows for one class."""
    periods: List[int] = []
    for day in assembled["days"]:
        for p in assembled["grid"].get(day, {}).get(str(class_no), {}):
            periods.append(int(p))
    periods = sorted(set(periods)) or list(range(1, 9))

    days = assembled["days"]
    rows: List[List[str]] = []
    warnings: List[str] = []
    for period in periods:
        row = [str(period)]
        for day in days:
            row.append(assembled["grid"].get(day, {}).get(str(class_no), {}).get(str(period), ""))
        rows.append(row)

    missing = [d for d in WEEKDAYS if d not in days]
    if missing:
        warnings.append("图片中未识别到：" + "、".join(missing))
    if class_no not in assembled["classes"]:
        warnings.append(f"未在图片中找到 {class_no} 班，输出为空课表")
    return rows, warnings


def write_csv(rows: Sequence[Sequence[str]], days: Sequence[str], path: str) -> None:
    """Write the projected schedule as UTF-8-with-BOM CSV."""
    header = ["序号"] + list(days)
    with open(path, "w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(header)
        for row in rows:
            writer.writerow(list(row) + [""] * (len(header) - len(row)))


def write_overlay(img: np.ndarray, tables: Sequence[TableResult], path: str) -> None:
    """Draw the detected grid for visual verification."""
    overlay = img.copy()
    for table in tables:
        for x in table.columns:
            cv2.line(overlay, (x, 0), (x, overlay.shape[0] - 1), (0, 0, 255), 1)
        for y in table.header:
            cv2.line(overlay, (table.columns[0], y), (table.columns[-1], y), (255, 0, 0), 1)
        for y1, _ in table.rows:
            cv2.line(overlay, (table.columns[0], y1), (table.columns[-1], y1), (255, 128, 0), 1)
    cv2.imwrite(path, overlay)


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------


def _structural_weekday_columns(
    mask: np.ndarray, columns: Sequence[int], rows: Sequence[Tuple[int, int]],
) -> List[int]:
    """Column indices that look like vertically-written 星期 columns.

    Last-resort table splitting for images whose header is gone entirely
    (cropped away, unreadable). A 星期 column holds one stacked label per day
    block: few ink bands, spread across most of the data region. Course columns
    have text in nearly every row; the 班 column has one digit band per row;
    empty columns have none — none of those match the pattern.
    """
    if len(rows) < 6 or len(columns) < 5:
        return []
    y_top, y_bot = rows[0][0], rows[-1][1]

    def row_of(centre: float) -> int:
        idx = next((i for i, (ry1, ry2) in enumerate(rows) if ry1 <= centre < ry2), None)
        if idx is None:
            idx = min(range(len(rows)),
                      key=lambda i: abs((rows[i][0] + rows[i][1]) / 2.0 - centre))
        return idx

    out: List[int] = []
    for i in range(len(columns) - 1):
        bands = _bands_in_column(mask, columns[i], columns[i + 1], y_top, y_bot)
        # A label's glyphs fragment under JPEG noise, so the band count is a
        # loose ceiling; the spread check below does the real work.
        if not 2 <= len(bands) <= 16:
            continue
        row_idxs = sorted({row_of((a + b) / 2.0) for a, b in bands})
        if len(row_idxs) < 2 or row_idxs[-1] - row_idxs[0] < len(rows) * 0.5:
            continue
        if max(b - a for a, b in bands) > 3.0 * len(rows) / len(bands):
            continue
        out.append(i)
    # A table needs at least a 班 column and one period column beside its label.
    spaced = [s for s in out if not out or s == out[0] or s - out[out.index(s) - 1] >= 4] \
        if out else out
    return spaced


def parse_class_number(name: str) -> Optional[int]:
    """Pull a class number out of a free-text class name (e.g. 高二(3)班 -> 3)."""
    if not name:
        return None
    numbers = re.findall(r"\d+", name)
    if not numbers:
        return None
    try:
        return int(numbers[-1])
    except ValueError:
        return None


def build_result(**kwargs) -> dict:
    result = {
        "success": False,
        "message": "",
        "csvPath": "",
        "gridPath": "",
        "overlayPath": "",
        "count": 0,
        "classes": [],
        "selectedClass": None,
        "days": [],
        "periods": [],
        "warnings": [],
        "stats": {},
    }
    result.update(kwargs)
    return result


def emit(result: dict, exit_code: int = 0) -> None:
    """Print the JSON contract on stdout and exit."""
    # Always emit UTF-8 regardless of the console code page, so the caller can
    # decode the JSON deterministically.
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except (AttributeError, ValueError):  # pragma: no cover - very old/odd stdio
        pass
    print(json.dumps(result, ensure_ascii=False))
    sys.exit(exit_code)


def detect_structure(gray: np.ndarray) -> Tuple[List[int], List[int], List[Tuple[int, int]]]:
    """Find the table grid; raises RuntimeError with a user-facing message on failure.

    Returns (column xs, header ys, data rows). The two rule orientations
    survive different binarisations: the local-mean threshold keeps thin
    vertical rules that Otsu drops on photos, while Otsu keeps the horizontal
    ones that the local mean smears out — so verticals and horizontals are
    measured on their respective stronger binary (they share the same
    coordinate frame, so mixing is safe).

    Attempts run strict-first and the first whose boundaries pass
    `_column_gaps_sane` wins: a pass with a hole where a rule cluster went
    undetected must not be trusted when a more tolerant one can repair it.
    """
    bw_otsu = binarize(gray)
    bw_adaptive = binarize_adaptive(gray)
    saw_columns = False
    fallback: Optional[Tuple[List[int], List[int], List[Tuple[int, int]]]] = None

    for v_fraction, close_h, h_bridge in ((V_RULE_RUN_FRACTION, 3, 3),
                                          (RELAXED_V_RULE_FRACTION, 7, 5)):
        xs = pad_outer_boundaries(
            detect_vertical_rules(bw_adaptive, v_fraction, 1, close_h), bw_adaptive)
        if len(xs) < 4:
            xs = pad_outer_boundaries(
                detect_vertical_rules(bw_otsu, v_fraction, 1, close_h), bw_otsu)
        if len(xs) < 4:
            continue
        saw_columns = True
        ys = detect_horizontal_rules(bw_otsu, xs[0], xs[-1], h_bridge)
        # The band above the first rule is only read as a cut-off row when it
        # holds text, so the binarisation and the table's own x-range travel with
        # the geometry (see `find_data_rows`).
        header, rows = find_data_rows(ys, mask=bw_otsu, x1=xs[0], x2=xs[-1])
        if not rows:
            continue
        structure = (xs, header, rows)
        if _column_gaps_sane(xs):
            return structure
        if fallback is None:
            fallback = structure

    if fallback is not None:
        return fallback
    message = ("未检测到数据行，请确认图片是一张课表" if saw_columns
               else "未检测到表格结构（找不到竖线），请确认图片是一张课表")
    raise RuntimeError(message)


def _propagate_block_structure(tables: Sequence["TableResult"]) -> None:
    """Sibling tables describe the same grade, so they share block structure.

    When one table's day blocks were recovered but a sibling lost its block
    signal entirely (one unlabeled block spanning all its rows — its 星期 and
    班 columns cropped or blurred away), the sibling inherits the recovered
    boundaries; its days are then recovered by sequence inference.
    """
    by_row_count: Dict[int, List[TableResult]] = defaultdict(list)
    for t in tables:
        by_row_count[len(t.rows)].append(t)
    for group in by_row_count.values():
        if len(group) < 2:
            continue
        n_rows = len(group[0].rows)
        template = None
        template_table = None
        for t in group:
            if len(t.blocks) >= 2:
                sizes = [e - s + 1 for s, e, _ in t.blocks]
                if max(sizes) - min(sizes) <= 2:
                    template = [(s, e) for s, e, _ in t.blocks]
                    template_table = t
                    break
        if not template:
            continue
        for t in group:
            if len(t.blocks) == 1 and t.blocks[0][0] == 0 \
                    and t.blocks[0][1] == n_rows - 1:
                t.blocks = [(s, e, "") for s, e in template]
                # The sibling's 班 digits describe the same physical rows; a
                # table with no readable digits of its own would otherwise
                # number its classes from the row index and miss the rows the
                # crop removed at the top.
                if not any(t.class_ok) and any(template_table.class_ok):
                    t.class_numbers = list(template_table.class_numbers)
                    t.class_ok = list(template_table.class_ok)


def flatten_illumination(img: np.ndarray) -> np.ndarray:
    """Divide out the low-frequency lighting, so one global threshold suffices.

    A hand shadow or a window gradient tilts the grey level across the page;
    `binarize` is a single global Otsu cut, so the shadowed half falls to the ink
    side and its rules disappear — measured on the photo-shaped variant of the
    sample fixture, where the horizontal rules came back as 44 data rows instead
    of 66 and this recovers all 66.
    """
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    background = cv2.GaussianBlur(gray, (0, 0), max(8.0, min(gray.shape[:2]) / 24.0))
    divided = cv2.divide(gray, np.maximum(background, 1), scale=200)
    normalised = cv2.normalize(divided, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
    return cv2.cvtColor(normalised, cv2.COLOR_GRAY2BGR)


def sharpness(img: np.ndarray) -> float:
    """Laplacian variance normalised by the image's own intensity variance.

    A plain Laplacian variance scales with contrast as well as with focus, so a
    dim or low-contrast photo scores as soft as a blurred one. Dividing by the
    intensity variance removes that: measured across the sample fixture's
    degradations this stays at 39-86 while the answer is recoverable and drops
    to 6-8 for the two where it is not (a half-size viewer page, a 0.45x round
    trip); on the report screenshot it separates the readable variants
    (3.6-9.4) from the 0.45x round trip (0.29).
    """
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY).astype(np.float32)
    laplacian = cv2.Laplacian(gray, cv2.CV_32F, ksize=3)
    return float(laplacian.var()) / max(1.0, float(np.var(gray)))


def _longest_rule_run(frame: np.ndarray) -> int:
    """Longest continuous horizontal ink run, in pixels.

    A page's horizontal rules are the most tilt-sensitive thing on it: a rule
    spanning 391px survives intact only when the residual tilt is small enough
    that its ink stays inside one scan row. On the sample fixture the measure
    reads 391 at the true angle and 278/311/327 at residuals of 0.2-0.4°, which
    is exactly the range where row detection starts losing rules. Vertical runs
    are included for a table whose horizontal rules are dotted away.
    """
    bw = binarize(sharpen(cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)))
    best = 0
    for line in list(bw) + list(bw.T):
        idx = np.flatnonzero(line)
        if idx.size < 2:
            continue
        breaks = np.flatnonzero(np.diff(idx) > 1)
        starts = np.r_[0, breaks + 1]
        ends = np.r_[breaks, idx.size - 1]
        best = max(best, int((idx[ends] - idx[starts]).max() + 1))
    return best


def _best_deskew_angle(img: np.ndarray) -> float:
    """The rotation that leaves the page's rules longest, measured directly.

    `estimate_skew` is the natural first guess, but it is biased low for small
    tilts (a long rule rotated by a fraction of a degree breaks into short
    segments whose median deviation is smaller than the true angle) and it has a
    floor: measured on the sample fixture, a true 0.2° tilt estimates as 0.0, a
    true 0.4° as 0.28, a true 0.6° as 0.37. The residual is not harmless —
    at 0.6° the frame deskewed by the estimate finds 49 of 66 data rows and the
    run scores 0%.

    So the guess is only a starting point. The candidates are the estimate and
    its 1.25/1.5/1.75 multiples, plus a fixed comb of small angles either side
    of zero for tilts the estimator cannot see at all, and the winner is the one
    that keeps the page's rules longest. That measure is a direct property of the
    page rather than a proxy, and it is decisive: on the sample fixture it reads
    391 at every true angle from 0.4° to 3.1° and falls to 219-330 at the
    residual the estimate would have left.

    0° is tried first and only beaten by a strictly longer run, so an upright
    scan is never resampled for nothing.
    """
    gray = sharpen(cv2.cvtColor(img, cv2.COLOR_BGR2GRAY))
    try:
        estimate = estimate_skew(binarize(gray))
    except Exception:  # noqa: BLE001 - skew is best-effort, never fatal
        estimate = 0.0

    candidates: List[float] = [0.0]
    if DESKEW_MIN_ANGLE <= abs(estimate) <= DESKEW_MAX_ANGLE:
        candidates += [estimate, estimate * 1.25, estimate * 1.5, estimate * 1.75]
    # Tilts below `DESKEW_MIN_ANGLE` are invisible to the estimator yet still
    # break long rules, so they get a fixed comb. The step is the estimator's own
    # Hough resolution (0.25°) at its smallest useful value.
    for delta in (0.15, 0.25, 0.35, 0.45):
        candidates += [delta, -delta]

    best_angle, best_run = 0.0, -1
    for angle in candidates:
        frame = rotate_image(img, angle) if angle else img
        run = _longest_rule_run(frame)
        if run > best_run:
            best_angle, best_run = angle, run
    return best_angle


def _structure_candidates(
    img: np.ndarray,
) -> List[Tuple[np.ndarray, Tuple[List[int], List[int], List[Tuple[int, int]]], float]]:
    """Every (frame, structure, density) pair worth considering, best effort.

    Three frames, because they fail on different inputs and none is a superset:

    * **native vs `normalize_scale` upscale.** Upscaling a small photo gives the
      rule-length test more to work with; it also blurs a 1px rule until the
      blur splits into two runs, which *adds* boundaries and shifts every cell
      after them by one column (measured on the sample fixture after a 0.72x
      downscale: 22 correct boundaries native, 33 wrong ones upscaled). A truly
      tiny image inverts this: at 0.52x the native frame loses the data region
      outright — 5 "rows" with an 85px gap against a 15px median — while the
      upscale recovers all 66.
    * **`flatten_illumination`.** A lighting gradient makes the global Otsu cut
      unusable on the shadowed half (measured: 44 of 66 rows on the
      photo-shaped variant, 66 with the lighting divided out).

    Each frame is deskewed when a tilt was actually detected: a 1.3° tilt left
    47 of 66 rows on the photo-shaped variant, where the deskewed frame
    recovers all 66. Trying the *undeskewed* frame as well was measured and is
    not worth it — on the sample fixture's 1.0° variant it handed the run to a
    frame that skipped the deskew and lost four of six day columns, because a
    tilt that small is real skew the raw frame cannot measure around.

    The third element is the frame's **pixel-density factor**: what to divide a
    measurement taken in this frame by to get source pixels. Only
    `normalize_scale` changes density, so it is 1.0 for the native and
    lighting-flattened frames and the upscale factor for the scaled one. It is
    reported per candidate because the caller cannot recover it from the frame's
    width: `rotate_image` *grows the canvas* (a 2.5° tilt takes 764px to 809px,
    ×1.059), so a width ratio silently includes the deskew and under-reports the
    source pitch by that much — measured on the sample fixture, a 2.5° rotation
    reported 14.21px for a genuine 15.00px pitch. Which matters because the pitch
    sets the `unresolved` flag, and a tilted photo of a readable page must not be
    pushed under that floor by its own deskew.
    """
    out: List[Tuple[np.ndarray, Tuple[List[int], List[int], List[Tuple[int, int]]], float]] = []
    frames: List[Tuple[np.ndarray, float]] = [(img, 1.0), (flatten_illumination(img), 1.0)]
    scaled = normalize_scale(img)
    if scaled.shape[:2] != img.shape[:2]:
        # density, not just width: this frame really does sample more pixels per
        # millimetre of page than the source did.
        frames.append((scaled, scaled.shape[1] / float(img.shape[1])))

    for frame, density in frames:
        # The deskew angle is chosen by measuring the page's own rules (see
        # `_best_deskew_angle`), not by trusting the skew estimate: the estimate
        # is biased low for small tilts, and its residual is what loses rows.
        angle = _best_deskew_angle(frame)
        candidate = rotate_image(frame, angle) if angle else frame
        try:
            structure = detect_structure(
                sharpen(cv2.cvtColor(candidate, cv2.COLOR_BGR2GRAY)))
        except RuntimeError:
            continue
        out.append((candidate, structure, density))
    return out


def detect_structure_multi(
    img: np.ndarray,
) -> Tuple[List[int], List[int], List[Tuple[int, int]], np.ndarray, float]:
    """Detect the grid over the frames that matter, keeping the most plausible one.

    Returns (xs, header, rows, frame, density) where `frame` is the image whose
    coordinates the geometry belongs to and `density` is that frame's
    pixel-density factor — divide a measurement taken in `frame` by it to get
    source pixels. It is needed because a frame's width does not determine it:
    deskewing grows the canvas without changing density (see
    `_structure_candidates`). `_structure_candidates` enumerates the frames and
    explains why more than one is needed.

    Two criteria pick the winner, in order:

    * **Row coverage.** All candidates look at the same content, so the one that
      finds materially fewer data rows has simply lost part of the table
      (measured at a 0.52x page scale: the native frame reports 5 "rows" whose
      gaps are 85px against a 15px rule pitch — the data region collapsed, and
      its perfectly uniform 85px gaps would otherwise score *better* than the
      upscale's honest 66). A candidate must keep at least
      `MULTISCALE_MIN_ROW_FRACTION` of the rows the best candidate found.
    * **`structure_score`** — uniform column widths and even row pitch.
    """
    candidates = _structure_candidates(img)
    if not candidates:
        raise RuntimeError("未检测到数据行，请确认图片是一张课表")

    most_rows = max(len(structure[2]) for _, structure, _d in candidates)
    floor = most_rows * MULTISCALE_MIN_ROW_FRACTION
    best_frame, best_structure, best_density = candidates[0]
    best_score = None
    for frame, structure, density in candidates:
        if len(structure[2]) < floor:
            continue
        score = structure_score(structure[0], structure[2])
        if best_score is None or (score is not None and score < best_score):
            best_frame, best_structure, best_density = frame, structure, density
            best_score = score

    # The upscale has to *earn* the run: it is a lossy step for reading, so a
    # near-tie must not hand the run to it. Without this the 0.85x page picks
    # the upscaled frame on a 2.6% better score, and its already-high pitch then
    # suppresses the reading upscale below — scoring 82.3% where the same table
    # read from the native frame's own pitch reaches 93.9% (measured, sample
    # fixture). Only a clear win switches frames.
    native_frame, native_structure, native_density = candidates[0]
    native_rows = len(native_structure[2])
    native_score = structure_score(native_structure[0], native_structure[2])
    if best_frame is not native_frame and native_rows >= floor:
        if (native_score is None or best_score is None
                or best_score * MULTISCALE_UPSCALE_MARGIN >= native_score):
            best_frame, best_structure, best_density = \
                native_frame, native_structure, native_density
    xs, header, rows = best_structure
    return xs, header, rows, best_frame, best_density


def _recognize_frame(img: np.ndarray, engine: OcrEngine, out_dir: str,
                     image_path: str) -> dict:
    """One full structure + recognition pass over one candidate frame.

    Raises RuntimeError when this frame holds no usable table, which is the
    caller's signal to try the next candidate crop rather than to give up: the
    first candidate is always the untouched image, so a plain scan still takes
    exactly the path it always did.
    """
    # Both resolution measures are taken on the *source* pixels, and before any
    # of the frames above are built: a candidate frame may be upscaled or
    # lighting-flattened, and either would mask exactly what is being measured
    # (measured: the half-size viewer page reads 8.4 unfaked and 63.2 once the
    # flattening candidate is applied).
    source_sharpness = sharpness(img)

    # Structure first, at whichever scale and rotation measures it best:
    # `detect_structure_multi` owns the deskew choice too, because rotating an
    # image whose rules are already blurred by downscaling destroys them where
    # leaving it alone reads the whole table (see `_structure_candidates`).
    xs, header, rows, img, density = detect_structure_multi(img)
    gray = sharpen(cv2.cvtColor(img, cv2.COLOR_BGR2GRAY))

    # The pitch is mapped back to the source's own pixels. The factor comes from
    # the chosen frame rather than from a width ratio, because a width ratio
    # silently folds in the deskew's canvas growth: `rotate_image` takes the
    # sample fixture's 764px to 809px at 2.5°, so a genuine 15.0px pitch was
    # reported as 14.21px and a tilted photo of a readable page could be pushed
    # under `UNRESOLVED_PITCH_PX` by its own deskew. Either measure below its
    # floor means the readings cannot be trusted, and the caller is told so
    # rather than being handed invented course names.
    source_pitch = median_row_pitch(rows) / density if density > 0 else 0.0

    # Recognition then runs at a scale whose row pitch is at the recogniser's
    # measured optimum. At a native ~11px pitch the 星期 column is under one
    # character wide and the day character is unreadable, so the table gets
    # silently anchored to the wrong weekdays. Scaling the image up and mapping
    # the measured geometry into the same frame fixes the reading without
    # moving a boundary.
    img, xs, header, rows = _scale_for_recognition(img, xs, header, rows)
    gray = sharpen(cv2.cvtColor(img, cv2.COLOR_BGR2GRAY))
    mask = text_only_mask(binarize(gray))

    # A column labelled 星期 begins a new table (a lone 星 counts when the
    # exact glyph pair did not survive the photo). Columns before the first
    # 星期 column still form a table — its own label may have been cropped or
    # blurred away, and its days are recovered by sequence inference later.
    labels = read_header_labels(engine, img, xs, header)
    starts = _weekday_table_starts(labels)
    if not starts:
        starts = _structural_weekday_columns(mask, xs, rows)
    if not starts or starts[0] > 0:
        starts.insert(0, 0)
    starts.append(len(xs) - 1)
    # A timetable never has more than ~12 content columns; a wider "single"
    # table means a missed split (one header read past recognition), so retry
    # with the structural weekday-column detection.
    if len(starts) == 2 and starts[1] - starts[0] > 14:
        structural = _structural_weekday_columns(mask, xs, rows)
        if structural:
            starts = ([0] if structural[0] > 0 else []) + structural
            starts.append(len(xs) - 1)

    tables: List[TableResult] = []
    for a, b in zip(starts, starts[1:]):
        columns = list(xs[a:b + 1])
        if len(columns) < 4:
            continue
        tables.append(recognize_table(engine, img, mask, columns, header, rows))
    tables = [t for t in tables if t.rows and t.period_columns]
    _propagate_block_structure(tables)
    if not tables:
        raise RuntimeError("未能解析出课程列，请确认图片是一张课表")

    assembled = assemble_grid(tables)
    if not assembled["days"]:
        raise RuntimeError("未能识别出任何星期信息，无法确定日期列")

    warnings: List[str] = []
    if assembled.pop("days_inferred", False):
        warnings.append("星期标注未能识别，已按版面顺序推断为周一之后依次排列，请核对")

    # Three independent signals that the readings cannot be trusted, combined
    # because each one has a measured blind spot:
    #
    #   * mean cell confidence — the direct signal, and the primary one: 0.80
    #     separates every destroyed input in the sweep (0.54-0.67, plus the
    #     report screenshot at 0.67) from every readable one (0.947-0.996).
    #   * normalized sharpness below 8.0 — catches a 0.45x round trip (6.30) that
    #     is *above* the confidence floor's reach (0.536) only because so little
    #     of it is read at all.
    #   * a sub-12px pitch combined with confidence under 0.95 — the page is
    #     physically thin, and the recogniser's readings are not the clean 0.95+
    #     of a healthy page. The confidence term is what keeps `down80` (11.8px
    #     but 95.2% correct at 0.956) from being flagged, while the report
    #     screenshot (11.0px, 0.906) still is.
    #
    # A run is still returned: a table to correct beats a blank screen. It is
    # flagged so the caller can ask for a better image instead of presenting
    # invented course names as fact.
    confidences = [c for t in tables for c in t.confidence.values()]
    mean_confidence = float(np.mean(confidences)) if confidences else 0.0
    unresolved_pitch = (0 < source_pitch < UNRESOLVED_PITCH_PX
                        and 0 < mean_confidence < UNRESOLVED_PITCH_CONFIDENCE)
    unresolved_blur = 0 < source_sharpness < UNRESOLVED_SHARPNESS
    # No confidences at all means the grid came back empty — nothing was read, so
    # there is nothing here to trust (mean_confidence is 0.0 and this catches it).
    unresolved_guess = mean_confidence < UNRESOLVED_MEAN_CONFIDENCE
    unresolved = unresolved_pitch or unresolved_blur or unresolved_guess
    if unresolved:
        if unresolved_pitch:
            reason = "每行仅 {:.0f} 像素".format(source_pitch)
        elif unresolved_blur:
            reason = "画面过于模糊"
        else:
            reason = "文字清晰度不足"
        warnings.append(
            f"图片分辨率偏低（{reason}），识别结果可能不准确，"
            "建议提供更清晰的课表图片或截图"
        )

    # The vocabulary consolidation runs only on pages the pipeline believes it
    # read. On an unreadable page the readings are noise, and a frequency rule
    # over noise manufactures plausible-looking names out of garbage — the
    # viewer screenshot produced 167 "corrections" (R→学, F→1, 甲→3) that would
    # have dressed a refused page up as a result. The flag above is the project's
    # own line between "read, with corrections" and "not read at all".
    corrections: List[Tuple[str, str, int]] = []
    if not unresolved:
        corrections = consolidate_grid(assembled, tables)
    if corrections:
        summary = "、".join(
            f"{src}→{dst}" + (f"（{n} 处）" if n > 1 else "")
            for src, dst, n in sorted(corrections, key=lambda item: -item[2]))
        total = sum(n for _src, _dst, n in corrections)
        warnings.append(f"已按课表自身的课程名统一 {total} 处疑似误读：{summary}，请核对")

    grid_path = os.path.join(out_dir, "grid.json")
    with open(grid_path, "w", encoding="utf-8") as handle:
        json.dump(
            {
                "image": os.path.abspath(image_path),
                "engine": engine.name,
                "days": assembled["days"],
                "classes": assembled["classes"],
                "grid": assembled["grid"],
                "tables": [
                    {
                        "columns": t.columns,
                        "header": t.header,
                        "rows": [[y1, y2] for y1, y2 in t.rows],
                        "labels": labels,
                        "class_numbers": t.class_numbers,
                        "blocks": t.blocks,
                        "periods": t.period_numbers,
                        "merged": t.merged,
                    }
                    for t in tables
                ],
            },
            handle,
            ensure_ascii=False,
            indent=1,
        )

    total = sum(len(t.rows) * len(t.period_columns) for t in tables)
    filled = sum(len(t.cells) for t in tables)
    return build_result(
        success=True,
        gridPath=os.path.abspath(grid_path),
        classes=assembled["classes"],
        days=assembled["days"],
        periods=sorted({int(p) for d in assembled["grid"].values()
                        for c in d.values() for p in c}),
        warnings=warnings,
        stats={
            "engine": engine.name,
            "tables": len(tables),
            "cells": total,
            "nonEmpty": filled,
            "rowPitch": round(source_pitch, 1),
            "sharpness": round(source_sharpness, 2),
            "unresolved": unresolved,
            "meanConfidence": round(mean_confidence, 3),
            "lowConfidence": sum(1 for c in confidences if c < LOW_CONFIDENCE),
            "consolidated": sum(n for _src, _dst, n in corrections),
        },
        _assembled=assembled,
        _tables=tables,
        _image=img,
    )


def run_recognition(image_path: str, out_dir: str, engine_preference: Optional[str]) -> dict:
    """Detect structure, recognise every table and return the result payload.

    The frame is tried as-is first, then — only if that finds no table — cropped
    to plausible paper regions. Leaving the untouched image first is what keeps
    this safe: a plain scan or an already-cropped page succeeds on the first and
    only attempt, so no heuristic can lose a table the old code found. The extra
    attempts exist for images where the timetable is only part of the picture,
    which failed for a reason that has nothing to do with the table: `binarize`
    is a *global* Otsu threshold, so a dark application border around the page
    reads as ink (a real viewer screenshot came out 64% ink) and the horizontal
    rule measurement dies with it — surfacing to the user as "未检测到数据行，
    请确认图片是一张课表" on an image whose table renders perfectly.

    When there is more than one candidate, the *structure* of each is measured
    first (cheap — no OCR) and the two most promising are recognised, the better
    result winning. Stopping at the first candidate whose structure merely
    *succeeds* is not enough, and it is measured rather than theorised: on a
    viewer screenshot whose page occupies part of the frame, an early bright
    sub-region yields a perfectly usable 2-day grid while a later, fuller crop of
    the same page yields 6 days and 666 cells against its 371. The first success
    wins under the old rule, which is the "structure detection degraded into a
    silently partial table" failure — the caller sees a valid-looking timetable
    with two thirds of it missing. Ranking by data rows and recognising the top
    two costs one extra OCR pass and never returns something worse than the
    first-success rule would have, because the first success is always among the
    candidates ranked and the winner is chosen on (days found, cells filled).

    The image is deliberately *not* pre-upscaled here: `_recognize_frame` picks
    the best of the native and upscaled structure measurements itself, and it
    can only do that if it is handed the original pixels (`normalize_scale`
    there is a no-op once the image is past `MIN_PROCESS_DIM`).
    """
    source = load_image(image_path)
    engine = create_engine(engine_preference)

    failure: Optional[RuntimeError] = None
    best_result: Optional[dict] = None
    best_rank = (-1, -1)
    best_grid: Optional[str] = None

    for index, (candidate, region) in enumerate(_ranked_candidates(source)):
        # Each candidate writes its own grid.json. They cannot share one path:
        # the winner is chosen *after* every attempt, so a shared path would be
        # overwritten by whichever crop ran last and the returned gridPath would
        # point at a rejected candidate's grid (measured: the viewer screenshot's
        # 41-row crop wrote 371 cells over the 63-row winner's 666).
        candidate_dir = (out_dir if index == 0
                         else os.path.join(out_dir, f"_candidate{index}"))
        os.makedirs(candidate_dir, exist_ok=True)
        try:
            result = _recognize_frame(candidate, engine, candidate_dir, image_path)
        except RuntimeError as exc:
            # This crop holds no usable table; remember why and try the next.
            # Only RuntimeError is caught: anything else (a missing engine, a
            # corrupt file) is not a framing problem and must surface as-is.
            failure = exc
            if region is not None:
                debug_note = f"裁剪 {region} 后仍失败"
                print(f"[info] {debug_note}: {exc}", file=sys.stderr)
            continue
        # The untouched frame is the page itself: when it yields a table, that
        # table is the answer and no crop is consulted. This is what keeps a
        # plain scan on exactly the path it always took.
        if region is None:
            _remove_candidate_dirs(out_dir)
            return result
        # For crops, more days and more filled cells is the better framing. The
        # comparison is explicit rather than "first success wins" because a
        # partial crop can pass structure detection perfectly — see the ranking
        # note in the docstring.
        rank = (len(result.get("days", [])), result.get("stats", {}).get("nonEmpty", 0))
        if rank > best_rank:
            best_result, best_rank = result, rank
            best_grid = os.path.join(candidate_dir, "grid.json")
        if index + 1 >= CANDIDATE_RECOGNITION_LIMIT:
            break

    if best_result is None:
        _remove_candidate_dirs(out_dir)
        raise failure if failure is not None else RuntimeError(
            "未能解析出课程列，请确认图片是一张课表")

    # Promote the winner's grid to the caller's directory, so `gridPath` and the
    # file it points at describe the result actually being returned.
    final_grid = os.path.join(out_dir, "grid.json")
    if best_grid is not None and os.path.abspath(best_grid) != os.path.abspath(final_grid):
        try:
            shutil.copyfile(best_grid, final_grid)
            best_result["gridPath"] = os.path.abspath(final_grid)
        except OSError as exc:  # pragma: no cover - disk-level failure
            print(f"[warn] 无法把胜出候选的 grid.json 复制到输出目录: {exc}",
                  file=sys.stderr)
    _remove_candidate_dirs(out_dir)
    return best_result


def _remove_candidate_dirs(out_dir: str) -> None:
    """Delete the per-candidate scratch directories, best effort."""
    try:
        for name in os.listdir(out_dir):
            path = os.path.join(out_dir, name)
            if name.startswith("_candidate") and os.path.isdir(path):
                shutil.rmtree(path, ignore_errors=True)
    except OSError:  # pragma: no cover - diagnostics only
        pass


def _ranked_candidates(
    source: np.ndarray,
) -> List[Tuple[np.ndarray, Optional[Tuple[int, int, int, int]]]]:
    """Page candidates, best-first by how much table their structure holds.

    The untouched frame is always first: it needs no OCR to justify itself, and
    keeping it at the head is what leaves a plain scan on the path it always
    took. The crops after it are ordered by data-row count, with
    `structure_score` breaking ties, because the number of rows a crop's
    structure resolves is what separates "a full table" from "a fragment of one"
    *before* any cell is read. Measured on a viewer screenshot (the page occupying
    part of the frame), the crops resolve 41, 60 and 63 rows, and the 63-row crop
    reads 666 cells / 6 days against the 41-row crop's 371 / 2.
    """
    candidates = page_candidates(source)
    if len(candidates) <= 1:
        return candidates

    scored: List[Tuple[int, float, int, np.ndarray, Optional[Tuple[int, int, int, int]]]] = []
    for i, (frame, region) in enumerate(candidates):
        if region is None:
            continue
        try:
            xs, _header, rows, _resolved, _density = detect_structure_multi(frame)
        except RuntimeError:
            # A crop whose structure does not resolve at all is simply not a
            # candidate; the loop still tries the untouched frame.
            continue
        score = structure_score(xs, rows)
        if score is None:
            continue
        scored.append((-len(rows), score, i, frame, region))

    if not scored:
        return candidates[:1]
    scored.sort(key=lambda item: (item[0], item[1]))
    ordered = [candidates[0]] + [(frame, region)
                                 for _n, _s, _i, frame, region in scored]
    print(f"[info] 结构候选 {len(candidates)} 个，按数据行数排序："
          f"{[int(-n) for n, _s, _i, _f, _r in scored]} 行", file=sys.stderr)
    return ordered


def finalize(result: dict, out_dir: str, class_no: Optional[int], class_name: str,
             debug: bool, image_path: str) -> dict:
    """Write the CSV for the chosen class and complete the result contract."""
    assembled = result.pop("_assembled")
    tables = result.pop("_tables")
    img = result.pop("_image")

    if class_no is None and class_name:
        class_no = parse_class_number(class_name)
    if class_no is not None and class_no not in assembled["classes"]:
        result["warnings"].append(
            f"班级编号 {class_no} 不在识别到的班级列表中"
        )

    result["selectedClass"] = class_no
    if class_no is not None:
        rows, warnings = project_csv(assembled, class_no)
        result["warnings"].extend(warnings)
        base = os.path.splitext(os.path.basename(image_path))[0]
        csv_path = os.path.join(out_dir, f"{class_name or base}_schedule.csv")
        write_csv(rows, assembled["days"], csv_path)
        result["csvPath"] = os.path.abspath(csv_path)
        result["count"] = len(rows)
        result["message"] = (
            f"识别成功：{len(assembled['days'])} 天 × {len(rows)} 节，"
            f"已导出 {class_no} 班课表"
        )
    else:
        result["message"] = "识别成功，但未能从班级名称中确定班级编号，请选择班级后重新导出"

    if debug and tables:
        try:
            overlay = os.path.join(out_dir, "overlay.png")
            write_overlay(img, tables, overlay)
            result["overlayPath"] = os.path.abspath(overlay)
        except Exception as exc:  # pragma: no cover - diagnostics only
            print(f"[warn] overlay failed: {exc}", file=sys.stderr)

    return result


def load_assembled_from_grid(grid_path: str) -> dict:
    with open(grid_path, encoding="utf-8") as handle:
        data = json.load(handle)
    return {"days": data["days"], "classes": data["classes"], "grid": data["grid"]}


def main(argv: Optional[Sequence[str]] = None) -> None:
    parser = argparse.ArgumentParser(description="识别课表图片并导出 CSV")
    parser.add_argument("--image", help="课表图片路径")
    parser.add_argument("--out", required=True, help="输出目录")
    parser.add_argument("--class", dest="class_name", default="", help="班级名称")
    parser.add_argument("--class-no", dest="class_no", type=int, default=None,
                        help="班级编号（图片 班 列中的数字）")
    parser.add_argument("--from-grid", dest="from_grid", default=None,
                        help="复用已识别的 grid.json，跳过 OCR")
    parser.add_argument("--engine", choices=["rapidocr3", "rapidocr", "tesseract"],
                        default=None,
                        help="强制使用指定 OCR 引擎")
    parser.add_argument("--debug", action="store_true", help="输出调试图层")
    args = parser.parse_args(argv)

    os.makedirs(args.out, exist_ok=True)

    try:
        if args.from_grid:
            if not os.path.exists(args.from_grid):
                emit(build_result(message=f"找不到 grid 文件：{args.from_grid}"), 1)
            assembled = load_assembled_from_grid(args.from_grid)
            result = build_result(
                success=True,
                gridPath=os.path.abspath(args.from_grid),
                classes=assembled["classes"],
                days=assembled["days"],
                periods=sorted({int(p) for day in assembled["grid"].values()
                                for cls in day.values() for p in cls}),
                _assembled=assembled,
                _tables=[],
                _image=np.zeros((1, 1, 3), np.uint8),
            )
            result = finalize(result, args.out, args.class_no, args.class_name, False,
                              args.image or args.from_grid)
            emit(result, 0)

        if not args.image:
            emit(build_result(message="缺少 --image 参数"), 2)
        if not os.path.exists(args.image):
            emit(build_result(message=f"图片不存在：{args.image}"), 1)

        result = run_recognition(args.image, args.out, args.engine)
        result = finalize(result, args.out, args.class_no, args.class_name,
                          args.debug, args.image)
        emit(result, 0)

    except Exception as exc:  # noqa: BLE001 - top-level guard, reported as JSON
        print(f"[error] {type(exc).__name__}: {exc}", file=sys.stderr)
        emit(build_result(message=f"识别失败：{type(exc).__name__}: {exc}"), 1)


if __name__ == "__main__":
    main()
